import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import legacy from "@vitejs/plugin-legacy";

// @ts-expect-error process is a nodejs global
const host = process.env.TAURI_DEV_HOST;

// https://vitejs.dev/config/
export default defineConfig(async () => ({
  base: "./",
  plugins: [
    react(),
    legacy({
      targets: ["safari >= 11", "ios >= 11", "chrome >= 60", "firefox >= 60"],
      renderModernChunks: true
    })
  ],
  build: {
    target: "es2015",
    cssTarget: "safari11"
  },
  clearScreen: false,
  server: {
    port: 1420,
    strictPort: true,
    host: host || false,
    hmr: host
      ? {
          protocol: "ws",
          host,
          port: 1421,
        }
      : undefined,
    watch: {
      ignored: ["**/src-tauri/**"],
    },
  },
}));
