import { useEffect } from 'react';
import { emit, listen } from '@tauri-apps/api/event';
import { useStore } from './stores/useStore';
import Preview from './components/control/Preview';
import Controls from './components/control/Controls';
import Settings from './components/control/Settings';

interface StoreSyncPayload {
  images: { id: string; name: string; assetUrl: string; path: string; targetPanel?: any; pairedImageId?: string; customDuration?: number }[];
  imagesCount: number;
  audioTracks: { id: string; name: string; assetUrl: string; path: string }[];
  audioSettings: any;
  settings: any;
  isPlaying: boolean;
  currentAudioIndex: number;
  triptych: any;
  isProjectionOpen: boolean;
  isFullPreviewOpen: boolean;
  currentAlbumName: string;
}

export default function ControlsWindowApp() {
  const isPlaying = useStore((s) => s.isPlaying);
  const isProjectionOpen = useStore((s) => s.isProjectionOpen);
  const settings = useStore((s) => s.settings);

  useEffect(() => {
    // Intercept store actions when in detached window and forward to main window
    const originalTogglePlay = useStore.getState().togglePlay;
    const originalSetPlaying = useStore.getState().setPlaying;
    const originalUpdateSettings = useStore.getState().updateSettings;
    const originalUpdateAudioSettings = useStore.getState().updateAudioSettings;
    const originalAdvanceSlideshow = useStore.getState().advanceSlideshow;
    const originalResetSlideshow = useStore.getState().resetSlideshow;
    const originalInitSlideshow = useStore.getState().initSlideshow;
    const originalNextAudioTrack = useStore.getState().nextAudioTrack;
    const originalPreviousAudioTrack = useStore.getState().previousAudioTrack;
    const originalSetProjectionOpen = useStore.getState().setProjectionOpen;
    const originalClearImages = useStore.getState().clearImages;
    const originalSetImageCustomDuration = useStore.getState().setImageCustomDuration;

    useStore.setState({
      togglePlay: () => {
        originalTogglePlay();
        emit('store-dispatch', { action: 'togglePlay' });
      },
      setPlaying: (playing: boolean) => {
        originalSetPlaying(playing);
        emit('store-dispatch', { action: 'setPlaying', payload: playing });
      },
      updateSettings: (partial: any) => {
        originalUpdateSettings(partial);
        emit('store-dispatch', { action: 'updateSettings', payload: partial });
      },
      updateAudioSettings: (partial: any) => {
        originalUpdateAudioSettings(partial);
        emit('store-dispatch', { action: 'updateAudioSettings', payload: partial });
      },
      advanceSlideshow: () => {
        originalAdvanceSlideshow();
        emit('store-dispatch', { action: 'advanceSlideshow' });
      },
      resetSlideshow: () => {
        originalResetSlideshow();
        emit('store-dispatch', { action: 'resetSlideshow' });
      },
      initSlideshow: () => {
        originalInitSlideshow();
        emit('store-dispatch', { action: 'initSlideshow' });
      },
      nextAudioTrack: () => {
        originalNextAudioTrack();
        emit('store-dispatch', { action: 'nextAudioTrack' });
      },
      previousAudioTrack: () => {
        originalPreviousAudioTrack();
        emit('store-dispatch', { action: 'previousAudioTrack' });
      },
      setProjectionOpen: (open: boolean) => {
        originalSetProjectionOpen(open);
        emit('store-dispatch', { action: 'setProjectionOpen', payload: open });
      },
      clearImages: () => {
        originalClearImages();
        emit('store-dispatch', { action: 'clearImages' });
      },
      setImageCustomDuration: (id: string, duration?: number) => {
        originalSetImageCustomDuration(id, duration);
        emit('store-dispatch', { action: 'setImageCustomDuration', payload: { id, duration } });
      },
      setImagePanelPosition: (id: string, position: any) => {
        useStore.getState().setImagePanelPosition(id, position);
        emit('store-dispatch', { action: 'setImagePanelPosition', payload: { id, position } });
      },
    });

    // Listen to updates from main window
    const unlistenSync = listen<StoreSyncPayload>('store-sync', (event) => {
      const data = event.payload;

      useStore.setState({
        images: (data.images || []) as any,
        audioTracks: (data.audioTracks || []) as any,
        audioSettings: data.audioSettings,
        settings: data.settings,
        isPlaying: data.isPlaying,
        currentAudioIndex: data.currentAudioIndex,
        triptych: data.triptych,
        isProjectionOpen: data.isProjectionOpen,
        isFullPreviewOpen: data.isFullPreviewOpen,
        currentAlbumName: data.currentAlbumName,
      });
    });

    // Request initial state from main window
    emit('request-store-sync', {});

    return () => {
      unlistenSync.then((fn) => fn());
    };
  }, []);

  // Keyboard shortcut: Space to toggle play/pause
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return;
      }
      if (e.key === ' ' || e.code === 'Space') {
        e.preventDefault();
        useStore.getState().togglePlay();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="h-screen w-screen bg-[#0f0f0f] text-white p-3 flex flex-col select-none overflow-hidden box-border">
      {/* Title Bar Header */}
      <div className="flex items-center justify-between pb-2.5 border-b border-gray-800 shrink-0">
        <div className="flex items-center gap-2">
          <span className="text-lg">🎛️</span>
          <div>
            <h1 className="text-xs font-bold uppercase tracking-wider text-gray-200">
              Controlli & Proiezione
            </h1>
            <p className="text-[10px] text-gray-400">Finestra Indipendente</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isPlaying && (
            <span className="flex items-center gap-1.5 text-[10px] px-2 py-0.5 rounded-full bg-green-950/90 text-green-400 border border-green-700/60 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <span>In Play</span>
            </span>
          )}
          {isProjectionOpen && (
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-950/90 text-indigo-300 border border-indigo-700/60 font-medium">
              {settings.projectionMode === 'dual' ? '🖥️🖥️ 2 Proiettori' : '🖥️ Proiezione Attiva'}
            </span>
          )}
        </div>
      </div>

      {/* Main Modules inside dedicated scrollable container */}
      <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-3 py-2">
        <Preview />
        <Controls />
        <Settings />
      </div>
    </div>
  );
}
