import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { useStore } from '../../stores/useStore';
import AudioItem from './AudioItem';

export default function AudioList() {
  const audioTracks = useStore((s) => s.audioTracks);
  const reorderAudioTracks = useStore((s) => s.reorderAudioTracks);
  const clearAudioTracks = useStore((s) => s.clearAudioTracks);
  const audioSettings = useStore((s) => s.audioSettings);
  const updateAudioSettings = useStore((s) => s.updateAudioSettings);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: { distance: 5 },
    })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      const oldIndex = audioTracks.findIndex((t) => t.id === active.id);
      const newIndex = audioTracks.findIndex((t) => t.id === over.id);
      reorderAudioTracks(oldIndex, newIndex);
    }
  };

  if (audioTracks.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-gray-500 py-12 px-4 text-center">
        <span className="text-4xl mb-3">🎵</span>
        <p className="text-sm font-medium text-gray-400">Nessuna traccia audio inserita.</p>
        <p className="text-xs text-gray-500 mt-1 max-w-xs">
          Importa file MP3, WAV, OGG o FLAC dalla zona qui sopra per usarli come colonna sonora durante lo slideshow.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Header with info and quick toggle */}
      <div className="flex items-center justify-between text-xs text-gray-400 mb-2 pb-1 border-b border-gray-800">
        <div className="flex items-center gap-2">
          <span>{audioTracks.length} {audioTracks.length === 1 ? 'traccia' : 'tracce'}</span>
          <span>•</span>
          <span className="text-[11px] text-gray-400">
            {audioSettings.mode === 'sequential' ? '🔄 Continua (Ordinata)' : '🔀 Casuale (Shuffle)'}
          </span>
        </div>

        <div className="flex items-center gap-3">
          {/* Audio Enabled Toggle */}
          <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-gray-300 hover:text-white">
            <input
              type="checkbox"
              checked={audioSettings.enabled}
              onChange={(e) => updateAudioSettings({ enabled: e.target.checked })}
              className="rounded accent-blue-500 cursor-pointer"
            />
            <span>Audio attivo</span>
          </label>

          {/* Svuota lista */}
          <button
            onClick={() => {
              if (window.confirm('Vuoi rimuovere tutte le tracce audio?')) {
                clearAudioTracks();
              }
            }}
            className="text-[11px] text-red-400 hover:text-red-300 cursor-pointer transition-colors"
          >
            Svuota tutto
          </button>
        </div>
      </div>

      {/* Volume & Amplification Booster Bar */}
      {audioSettings.enabled && (
        <div className="bg-gray-900/90 border border-gray-800 rounded-lg p-2.5 mb-2.5 flex flex-col gap-1.5 shrink-0">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-gray-200">🔊 Volume Slideshow & Anteprima</span>
              {audioSettings.volume > 1.0 ? (
                <span className="px-1.5 py-0.2 rounded text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold flex items-center gap-1">
                  <span>⚡ Amplificazione Boost</span>
                  <span>(+{Math.round((audioSettings.volume - 1.0) * 100)}%)</span>
                </span>
              ) : (
                <span className="text-[10px] text-gray-400 font-normal">
                  (Standard)
                </span>
              )}
            </div>
            <span className={`font-bold text-sm ${audioSettings.volume > 1.0 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {Math.round(audioSettings.volume * 100)}%
            </span>
          </div>

          <div className="flex items-center gap-2.5">
            <span className="text-[10px] text-gray-500">0%</span>
            <input
              type="range"
              min={0}
              max={2.5}
              step={0.05}
              value={audioSettings.volume}
              onChange={(e) => updateAudioSettings({ volume: Number(e.target.value) })}
              className={`flex-1 h-2 bg-gray-700 rounded cursor-pointer ${
                audioSettings.volume > 1.0 ? 'accent-amber-500' : 'accent-emerald-500'
              }`}
              title="Regola il volume dell'audio (fino al 250% con amplificazione per registrazioni e proiettore)"
            />
            <span className="text-[10px] text-amber-500 font-bold">250% ⚡</span>
          </div>

          <div className="flex items-center justify-between gap-1.5 pt-0.5">
            <span className="text-[10px] text-gray-500">Scelta rapida:</span>
            <div className="flex items-center gap-1">
              {[
                { label: '50%', val: 0.5 },
                { label: '100% Normale', val: 1.0 },
                { label: '⚡ 150% Forte', val: 1.5 },
                { label: '⚡ 200% Doppio', val: 2.0 },
                { label: '⚡ 250% Max', val: 2.5 },
              ].map((p) => (
                <button
                  key={p.val}
                  type="button"
                  onClick={() => updateAudioSettings({ volume: p.val })}
                  className={`px-2 py-0.5 rounded text-[10px] cursor-pointer transition-colors ${
                    Math.abs(audioSettings.volume - p.val) < 0.01
                      ? p.val > 1.0
                        ? 'bg-amber-600 text-white font-bold shadow'
                        : 'bg-emerald-600 text-white font-bold shadow'
                      : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Reorderable list */}
      <div className="flex-1 overflow-y-auto pr-1 flex flex-col gap-2">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={audioTracks.map((t) => t.id)}
            strategy={verticalListSortingStrategy}
          >
            <div className="flex flex-col gap-2">
              {audioTracks.map((track, index) => (
                <AudioItem key={track.id} track={track} index={index} />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      </div>
    </div>
  );
}
