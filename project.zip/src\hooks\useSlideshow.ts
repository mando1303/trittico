import { useEffect, useRef } from 'react';
import { useStore } from '../stores/useStore';
import { emit, listen } from '@tauri-apps/api/event';

export function useSlideshow() {
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isPlaying = useStore((s) => s.isPlaying);
  const settings = useStore((s) => s.settings);
  const triptych = useStore((s) => s.triptych);
  const images = useStore((s) => s.images);
  const advanceSlideshow = useStore((s) => s.advanceSlideshow);

  // Emit triptych state to projection window whenever it changes
  useEffect(() => {
    emit('triptych-update', {
      panels: triptych.panels,
      activePanel: triptych.activePanel,
      fadeDuration: settings.fadeDuration,
      panelGap: settings.panelGap ?? 0,
      outerMargin: settings.outerMargin ?? 0,
      centerOverlap: settings.centerOverlap ?? 0,
      edgeBlend: settings.edgeBlend ?? false,
    });
  }, [triptych.panels, triptych.activePanel, settings.fadeDuration, settings.panelGap, settings.outerMargin, settings.centerOverlap, settings.edgeBlend]);

  // Respond to on-demand requests for triptych state (e.g. newly opened projection windows)
  useEffect(() => {
    const unlisten = listen('request-triptych-update', () => {
      emit('triptych-update', {
        panels: triptych.panels,
        activePanel: triptych.activePanel,
        fadeDuration: settings.fadeDuration,
        panelGap: settings.panelGap ?? 0,
        outerMargin: settings.outerMargin ?? 0,
        centerOverlap: settings.centerOverlap ?? 0,
        edgeBlend: settings.edgeBlend ?? false,
      });
    });
    return () => {
      unlisten.then((fn) => fn());
    };
  }, [triptych.panels, triptych.activePanel, settings.fadeDuration, settings.panelGap, settings.outerMargin, settings.centerOverlap, settings.edgeBlend]);

  // Broadcast state to remote controller window
  useEffect(() => {
    emit('slideshow-state', {
      isPlaying,
      activePanel: triptych.activePanel,
      interval: settings.interval,
      currentStepDuration: settings.interval,
      mode: settings.mode,
      hasImages: images.length >= 1,
    });
  }, [isPlaying, triptych.activePanel, settings.interval, settings.mode, images.length]);

  // Listen for state requests from separate controller window
  useEffect(() => {
    const unlistenReq = listen('request-slideshow-state', () => {
      emit('slideshow-state', {
        isPlaying,
        activePanel: triptych.activePanel,
        interval: settings.interval,
        currentStepDuration: settings.interval,
        mode: settings.mode,
        hasImages: images.length >= 1,
      });
    });

    const unlistenCtrl = listen<{ action: 'toggle-play' | 'advance' | 'stop' | 'play' | 'pause' | 'volume-up' | 'volume-down' | 'set-volume'; value?: number }>(
      'slideshow-control',
      (event) => {
        const { action, value } = event.payload;
        const store = useStore.getState();
        if (action === 'toggle-play') {
          store.togglePlay();
        } else if (action === 'play') {
          if (!store.isPlaying) {
            store.togglePlay();
          }
        } else if (action === 'pause') {
          store.setPlaying(false);
        } else if (action === 'advance') {
          store.advanceSlideshow();
        } else if (action === 'stop') {
          store.resetSlideshow();
        } else if (action === 'volume-up') {
          const current = store.audioSettings.volume;
          const next = Math.min(2.5, Math.round((current + 0.1) * 10) / 10);
          store.updateAudioSettings({ volume: next });
        } else if (action === 'volume-down') {
          const current = store.audioSettings.volume;
          const next = Math.max(0, Math.round((current - 0.1) * 10) / 10);
          store.updateAudioSettings({ volume: next });
        } else if (action === 'set-volume' && typeof value === 'number') {
          store.updateAudioSettings({ volume: Math.max(0, Math.min(2.5, value)) });
        }
      }
    );

    return () => {
      unlistenReq.then((fn) => fn());
      unlistenCtrl.then((fn) => fn());
    };
  }, [isPlaying, triptych.activePanel, settings.interval, settings.mode, images.length]);

  // Slideshow auto-advance timer: ticks continuously at settings.interval
  // Subsequent photos continue changing according to the general album interval without waiting!
  useEffect(() => {
    const playImages = settings.playImages ?? true;
    if (!isPlaying || !playImages || images.length === 0) {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
      return;
    }

    const durationMs = Math.max(1, settings.interval) * 1000;

    timeoutRef.current = setTimeout(() => {
      advanceSlideshow();
    }, durationMs);

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    };
  }, [
    isPlaying,
    settings.playImages,
    settings.interval,
    images.length,
    triptych.stepCount,
    advanceSlideshow,
  ]);

  return { isPlaying, triptych, settings };
}
