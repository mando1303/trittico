import { useState } from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { invoke } from '@tauri-apps/api/core';
import { GalleryImage } from '../../types';
import { useStore } from '../../stores/useStore';

interface Props {
  image: GalleryImage;
  index: number;
}

export default function GalleryItem({ image, index }: Props) {
  const images = useStore((s) => s.images);
  const removeImage = useStore((s) => s.removeImage);
  const setPairedImage = useStore((s) => s.setPairedImage);
  const setImagePanelPosition = useStore((s) => s.setImagePanelPosition);
  const setImageCustomDuration = useStore((s) => s.setImageCustomDuration);
  const settings = useStore((s) => s.settings);

  const [isPairingOpen, setIsPairingOpen] = useState(false);
  const [isDurationOpen, setIsDurationOpen] = useState(false);
  const [isPositionModalOpen, setIsPositionModalOpen] = useState(false);
  const [tempDuration, setTempDuration] = useState<number>(image.customDuration || settings.interval || 5);

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: image.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const pairedImage = image.pairedImageId
    ? images.find((img) => img.id === image.pairedImageId)
    : null;
  const pairedIndex = image.pairedImageId
    ? images.findIndex((img) => img.id === image.pairedImageId)
    : -1;

  const targetPanel = image.targetPanel || 'any';

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={`relative group rounded-lg overflow-hidden bg-gray-800 aspect-square cursor-grab active:cursor-grabbing border ${
        image.pairedImageId
          ? 'border-amber-500/80 shadow-md shadow-amber-500/10'
          : targetPanel === 'random'
          ? 'border-fuchsia-500/80 shadow-md shadow-fuchsia-500/20 ring-1 ring-fuchsia-500/50'
          : targetPanel === 'left'
          ? 'border-blue-500/80 shadow-md shadow-blue-500/10'
          : targetPanel === 'center'
          ? 'border-emerald-500/80 shadow-md shadow-emerald-500/10'
          : targetPanel === 'right'
          ? 'border-purple-500/80 shadow-md shadow-purple-500/10'
          : 'border-gray-700/50'
      }`}
    >
      <img
        src={image.assetUrl}
        alt={image.name}
        className="w-full h-full object-contain"
        draggable={false}
        onError={async (e) => {
          try {
            const b64 = await invoke<string>('read_image_base64', { path: image.path });
            if (b64) {
              (e.target as HTMLImageElement).src = b64;
            }
          } catch (err) {
            console.error('Image load fallback failed:', err);
          }
        }}
      />

      {/* Index badge */}
      <div className="absolute top-1 left-1 bg-black/70 text-white text-xs px-1.5 py-0.5 rounded">
        {index + 1}
      </div>

      {/* Pairing badge (if paired) */}
      {pairedImage && (
        <div
          className="absolute top-1 left-8 bg-amber-600/90 text-white text-[10px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1 shadow"
          title={`Questa foto viene immediatamente affiancata alla Foto #${pairedIndex + 1} (${pairedImage.name})`}
        >
          <span>🔗 ➔ #{pairedIndex + 1}</span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setPairedImage(image.id, null);
            }}
            className="hover:text-red-200 cursor-pointer ml-0.5"
            title="Scollega abbinamento"
          >
            ✕
          </button>
        </div>
      )}

      {/* Target Panel Position badge */}
      {targetPanel !== 'any' && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            setIsPositionModalOpen(true);
          }}
          className={`absolute top-1 ${
            pairedImage ? 'left-24' : 'left-8'
          } text-white text-[10px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1 shadow cursor-pointer ${
            targetPanel === 'random'
              ? 'bg-fuchsia-600 hover:bg-fuchsia-500 border border-fuchsia-400/50'
              : targetPanel === 'left'
              ? 'bg-blue-600 hover:bg-blue-500'
              : targetPanel === 'center'
              ? 'bg-emerald-600 hover:bg-emerald-500'
              : 'bg-purple-600 hover:bg-purple-500'
          }`}
          title={
            targetPanel === 'random'
              ? 'Posizione Casuale: compare a sorte in Posizione 1 (Sinistra), 2 (Centro) o 3 (Destra). Clicca per modificare.'
              : targetPanel === 'left'
              ? 'Posizione fissa: 1 - Sinistra. Clicca per modificare.'
              : targetPanel === 'center'
              ? 'Posizione fissa: 2 - Centro. Clicca per modificare.'
              : 'Posizione fissa: 3 - Destra. Clicca per modificare.'
          }
        >
          <span>
            {targetPanel === 'random'
              ? '🎲 Pos. Casuale'
              : targetPanel === 'left'
              ? '◀ 1: Sinistra'
              : targetPanel === 'center'
              ? '● 2: Centro'
              : '▶ 3: Destra'}
          </span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setImagePanelPosition(image.id, 'any');
            }}
            className="hover:text-red-200 cursor-pointer ml-0.5 text-[9px]"
            title="Rimuovi vincolo di posizione"
          >
            ✕
          </button>
        </div>
      )}

      {/* Custom Duration Badge (if set) */}
      {image.customDuration && image.customDuration > 0 && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            setTempDuration(image.customDuration || settings.interval);
            setIsDurationOpen(true);
          }}
          className="absolute top-6 left-1 bg-sky-600 hover:bg-sky-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1 shadow cursor-pointer border border-sky-400/50 z-10"
          title={`Durata personalizzata: appare per ${image.customDuration} secondi anziché ${settings.interval}s. Clicca per modificare o reimpostare.`}
        >
          <span>⏱️ {image.customDuration}s</span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setImageCustomDuration(image.id, undefined);
            }}
            className="hover:text-red-200 cursor-pointer ml-0.5 text-[9px]"
            title="Ripristina durata globale predefinita"
          >
            ✕
          </button>
        </div>
      )}

      {/* Position configuration button (on hover or top right) */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          setIsPositionModalOpen(!isPositionModalOpen);
        }}
        className={`absolute top-1 right-[76px] bg-gray-900/80 hover:bg-fuchsia-600 text-white w-5 h-5 rounded-full text-xs flex items-center justify-center transition-all cursor-pointer ${
          isPositionModalOpen || targetPanel !== 'any'
            ? 'opacity-100 bg-fuchsia-600 ring-1 ring-fuchsia-400'
            : 'opacity-0 group-hover:opacity-100'
        }`}
        title={
          targetPanel === 'random'
            ? 'Posizione Casuale (1, 2 o 3) - Clicca per modificare'
            : targetPanel === 'left'
            ? 'Posizione 1: Sinistra - Clicca per modificare'
            : targetPanel === 'center'
            ? 'Posizione 2: Centro - Clicca per modificare'
            : targetPanel === 'right'
            ? 'Posizione 3: Destra - Clicca per modificare'
            : 'Imposta posizione di apparizione per questa foto (Casuale 1/2/3, Sinistra, Centro, Destra)'
        }
      >
        {targetPanel === 'random' ? '🎲' : '📍'}
      </button>

      {/* Custom duration button (on hover or top right) */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          setTempDuration(image.customDuration || settings.interval);
          setIsDurationOpen(!isDurationOpen);
        }}
        className={`absolute top-1 right-[52px] bg-gray-900/80 hover:bg-sky-600 text-white w-5 h-5 rounded-full text-xs flex items-center justify-center transition-all cursor-pointer ${
          isDurationOpen || image.customDuration ? 'opacity-100 bg-sky-600 ring-1 ring-sky-400' : 'opacity-0 group-hover:opacity-100'
        }`}
        title={image.customDuration ? `Modifica durata personalizzata (${image.customDuration}s)` : "Personalizza durata (secondi di apparizione) per questa foto"}
      >
        ⏱️
      </button>

      {/* Pairing button (on hover or top right) */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          setIsPairingOpen(!isPairingOpen);
        }}
        className={`absolute top-1 right-7 bg-gray-900/80 hover:bg-amber-600 text-white w-5 h-5 rounded-full text-xs flex items-center justify-center transition-all cursor-pointer ${
          isPairingOpen || image.pairedImageId ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
        }`}
        title={image.pairedImageId ? "Modifica immagine abbinata" : "Abbina un'altra foto per affiancarla"}
      >
        🔗
      </button>

      {/* Remove button */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          removeImage(image.id);
        }}
        className="absolute top-1 right-1 bg-red-600/80 hover:bg-red-600 text-white 
                   w-5 h-5 rounded-full text-xs flex items-center justify-center
                   opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
        title="Rimuovi immagine"
      >
        ✕
      </button>

      {/* Quick Position Selector Pill (appears on hover) */}
      <div
        onClick={(e) => e.stopPropagation()}
        className="absolute bottom-6 left-1 right-1 z-10 flex items-center justify-center gap-0.5 bg-black/90 backdrop-blur-xs p-0.5 rounded border border-gray-700/70 opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
      >
        <button
          type="button"
          onClick={() => setImagePanelPosition(image.id, targetPanel === 'random' ? 'any' : 'random')}
          className={`flex-1 py-0.5 px-0.5 rounded text-[9px] font-bold transition-colors cursor-pointer text-center truncate ${
            targetPanel === 'random'
              ? 'bg-fuchsia-600 text-white shadow ring-1 ring-fuchsia-400'
              : 'text-fuchsia-300 hover:text-white hover:bg-gray-800'
          }`}
          title="🎲 Posizione Casuale: compare a sorte in Posizione 1 (Sinistra), 2 (Centro) o 3 (Destra)"
        >
          🎲 Caso
        </button>
        <button
          type="button"
          onClick={() => setImagePanelPosition(image.id, targetPanel === 'left' ? 'any' : 'left')}
          className={`flex-1 py-0.5 px-0.5 rounded text-[9px] font-medium transition-colors cursor-pointer text-center truncate ${
            targetPanel === 'left'
              ? 'bg-blue-600 text-white font-bold shadow'
              : 'text-gray-400 hover:text-white hover:bg-gray-800'
          }`}
          title="◀ Posizione 1: Sinistra"
        >
          ◀ 1
        </button>
        <button
          type="button"
          onClick={() => setImagePanelPosition(image.id, targetPanel === 'center' ? 'any' : 'center')}
          className={`flex-1 py-0.5 px-0.5 rounded text-[9px] font-medium transition-colors cursor-pointer text-center truncate ${
            targetPanel === 'center'
              ? 'bg-emerald-600 text-white font-bold shadow'
              : 'text-gray-400 hover:text-white hover:bg-gray-800'
          }`}
          title="● Posizione 2: Centro"
        >
          ● 2
        </button>
        <button
          type="button"
          onClick={() => setImagePanelPosition(image.id, targetPanel === 'right' ? 'any' : 'right')}
          className={`flex-1 py-0.5 px-0.5 rounded text-[9px] font-medium transition-colors cursor-pointer text-center truncate ${
            targetPanel === 'right'
              ? 'bg-purple-600 text-white font-bold shadow'
              : 'text-gray-400 hover:text-white hover:bg-gray-800'
          }`}
          title="▶ Posizione 3: Destra"
        >
          ▶ 3
        </button>
      </div>

      {/* Filename */}
      <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs p-1 truncate">
        {image.name}
      </div>

      {/* Pairing selection popover */}
      {isPairingOpen && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute inset-0 bg-gray-950/95 z-30 p-2 flex flex-col text-left rounded-lg overflow-hidden border border-amber-500"
        >
          <div className="flex items-center justify-between border-b border-gray-700 pb-1 mb-1">
            <span className="text-[11px] font-bold text-amber-400">Scegli foto da affiancare:</span>
            <button
              onClick={() => setIsPairingOpen(false)}
              className="text-xs text-gray-400 hover:text-white"
            >
              ✕
            </button>
          </div>

          <div className="flex-1 overflow-y-auto flex flex-col gap-1 pr-1">
            {images.filter((img) => img.id !== image.id).map((targetImg) => {
              const targetIdx = images.findIndex((x) => x.id === targetImg.id);
              const isSelected = image.pairedImageId === targetImg.id;
              return (
                <button
                  key={targetImg.id}
                  onClick={() => {
                    setPairedImage(image.id, targetImg.id);
                    setIsPairingOpen(false);
                  }}
                  className={`flex items-center gap-1.5 p-1 rounded text-[11px] text-left transition-colors cursor-pointer ${
                    isSelected ? 'bg-amber-600 text-white' : 'bg-gray-800 hover:bg-gray-700 text-gray-300'
                  }`}
                >
                  <span className="font-bold text-[10px] w-4 shrink-0">#{targetIdx + 1}</span>
                  <img src={targetImg.assetUrl} alt="" className="w-5 h-5 object-cover rounded shrink-0 bg-black" />
                  <span className="truncate flex-1">{targetImg.name}</span>
                </button>
              );
            })}
            {images.length <= 1 && (
              <p className="text-[10px] text-gray-400">Carica altre immagini per poterle abbinare.</p>
            )}
          </div>

          {image.pairedImageId && (
            <button
              onClick={() => {
                setPairedImage(image.id, null);
                setIsPairingOpen(false);
              }}
              className="mt-1 py-0.5 text-[10px] text-red-400 hover:text-red-300 text-center border-t border-gray-800 pt-1 cursor-pointer"
            >
              Scollega foto abbinata
            </button>
          )}
        </div>
      )}

      {/* Duration configuration modal - Centered on screen, never clipped */}
      {isDurationOpen && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            setIsDurationOpen(false);
          }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 cursor-default"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-gray-900 border border-sky-500/80 rounded-xl p-5 max-w-sm w-full shadow-2xl flex flex-col gap-4 text-left"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-gray-800 pb-2">
              <div className="flex items-center gap-2">
                <span className="text-xl">⏱️</span>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Durata Foto #{index + 1}
                  </h3>
                  <p className="text-[11px] text-gray-400 truncate max-w-[200px]">
                    {image.name}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsDurationOpen(false)}
                className="w-7 h-7 rounded-full bg-gray-800 hover:bg-gray-700 text-gray-400 hover:text-white flex items-center justify-center text-sm cursor-pointer transition-colors"
                title="Chiudi senza salvare"
              >
                ✕
              </button>
            </div>

            {/* Thumbnail Preview & Info */}
            <div className="flex items-center gap-3 bg-gray-950 p-2.5 rounded-lg border border-gray-800">
              <img
                src={image.assetUrl}
                alt={image.name}
                className="w-16 h-16 object-cover rounded bg-black shrink-0 border border-gray-700"
              />
              <div className="flex flex-col gap-1 text-xs">
                <span className="text-gray-300">
                  Durata predefinita album:{' '}
                  <strong className="text-sky-300">{settings.interval}s</strong>
                </span>
                <span className="text-gray-400 text-[11px] leading-snug">
                  Scegli per quanti secondi questa singola foto deve rimanere visibile sul trittico.
                </span>
              </div>
            </div>

            {/* Stepper with number input */}
            <div className="flex flex-col items-center gap-1.5 bg-gray-950/70 p-3 rounded-lg border border-gray-800">
              <span className="text-[11px] text-gray-400 font-medium">Secondi di permanenza:</span>
              <div className="flex items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => setTempDuration((prev) => Math.max(1, prev - 1))}
                  className="w-9 h-9 bg-gray-800 hover:bg-gray-700 text-white rounded-lg font-bold text-lg flex items-center justify-center cursor-pointer shadow transition-colors active:scale-95"
                >
                  -
                </button>
                <div className="flex items-center gap-1.5 px-3 py-1 bg-gray-900 rounded-lg border border-gray-700">
                  <input
                    type="number"
                    min={1}
                    max={300}
                    value={tempDuration}
                    onChange={(e) => setTempDuration(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-14 text-center bg-transparent text-white font-bold text-lg outline-none"
                    autoFocus
                  />
                  <span className="text-xs text-sky-400 font-bold">sec</span>
                </div>
                <button
                  type="button"
                  onClick={() => setTempDuration((prev) => Math.min(300, prev + 1))}
                  className="w-9 h-9 bg-gray-800 hover:bg-gray-700 text-white rounded-lg font-bold text-lg flex items-center justify-center cursor-pointer shadow transition-colors active:scale-95"
                >
                  +
                </button>
              </div>
            </div>

            {/* Presets */}
            <div className="flex flex-col gap-1.5">
              <span className="text-[11px] text-gray-400 font-medium">Scelta rapida:</span>
              <div className="grid grid-cols-5 gap-1.5">
                {[3, 5, 8, 10, 15].map((sec) => (
                  <button
                    key={sec}
                    type="button"
                    onClick={() => setTempDuration(sec)}
                    className={`py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all text-center ${
                      tempDuration === sec
                        ? 'bg-sky-600 text-white shadow ring-2 ring-sky-400'
                        : 'bg-gray-800 hover:bg-gray-750 text-gray-300'
                    }`}
                  >
                    {sec}s
                  </button>
                ))}
              </div>
            </div>

            {/* Action Buttons: Big, prominent "IMPOSTA" button */}
            <div className="flex flex-col gap-2 pt-2 border-t border-gray-800">
              <button
                type="button"
                onClick={() => {
                  setImageCustomDuration(image.id, tempDuration);
                  setIsDurationOpen(false);
                }}
                className="w-full py-2.5 bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white rounded-lg text-sm font-bold cursor-pointer transition-all shadow-lg shadow-sky-600/30 flex items-center justify-center gap-2 active:scale-98"
              >
                <span>✓</span>
                <span>IMPOSTA DURATA ({tempDuration}s)</span>
              </button>

              <div className="flex items-center justify-between gap-2">
                {image.customDuration ? (
                  <button
                    type="button"
                    onClick={() => {
                      setImageCustomDuration(image.id, undefined);
                      setIsDurationOpen(false);
                    }}
                    className="py-1 px-2 text-xs text-amber-400 hover:text-amber-300 cursor-pointer transition-colors"
                  >
                    Ripristina durata globale ({settings.interval}s)
                  </button>
                ) : (
                  <span />
                )}
                <button
                  type="button"
                  onClick={() => setIsDurationOpen(false)}
                  className="py-1 px-2 text-xs text-gray-400 hover:text-white cursor-pointer transition-colors"
                >
                  Annulla
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Position configuration modal - Centered on screen, compact & never clipped */}
      {isPositionModalOpen && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            setIsPositionModalOpen(false);
          }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 sm:p-4 cursor-default"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-gray-900 border border-fuchsia-500/80 rounded-xl max-w-sm w-full max-h-[75vh] shadow-2xl flex flex-col text-left overflow-hidden"
          >
            {/* Header - Fixed at top */}
            <div className="flex items-center justify-between border-b border-gray-800 px-4 py-2.5 shrink-0 bg-gray-900/95">
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-lg shrink-0">📍</span>
                <div className="min-w-0">
                  <h3 className="text-sm font-bold text-white truncate">
                    Posizione Foto #{index + 1}
                  </h3>
                  <p className="text-[11px] text-gray-400 truncate max-w-[220px]">
                    {image.name}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsPositionModalOpen(false)}
                className="w-7 h-7 rounded-full bg-gray-800 hover:bg-gray-700 text-gray-400 hover:text-white flex items-center justify-center text-sm cursor-pointer transition-colors shrink-0 ml-2"
                title="Chiudi"
              >
                ✕
              </button>
            </div>

            {/* Scrollable Content Body */}
            <div className="flex-1 overflow-y-auto px-4 py-3 flex flex-col gap-2.5 min-h-0">
              {/* Thumbnail Preview & Info */}
              <div className="flex items-center gap-2.5 bg-gray-950 p-2 rounded-lg border border-gray-800 shrink-0">
                <img
                  src={image.assetUrl}
                  alt={image.name}
                  className="w-12 h-12 object-cover rounded bg-black shrink-0 border border-gray-700"
                />
                <div className="flex flex-col gap-0.5 text-xs min-w-0">
                  <span className="text-gray-300 font-medium text-[11px]">
                    Stato attuale:{' '}
                    <strong className={
                      targetPanel === 'random' ? 'text-fuchsia-400' :
                      targetPanel === 'left' ? 'text-blue-400' :
                      targetPanel === 'center' ? 'text-emerald-400' :
                      targetPanel === 'right' ? 'text-purple-400' :
                      'text-gray-400'
                    }>
                      {targetPanel === 'random' ? '🎲 Casuale (Pos. 1, 2 o 3)' :
                       targetPanel === 'left' ? '◀ Posizione 1 (Sinistra)' :
                       targetPanel === 'center' ? '● Posizione 2 (Centro)' :
                       targetPanel === 'right' ? '▶ Posizione 3 (Destra)' :
                       '🔄 Predefinita (Ordinata)'}
                    </strong>
                  </span>
                  <span className="text-gray-400 text-[10px] leading-tight">
                    Scegli dove far comparire questa foto sul trittico.
                  </span>
                </div>
              </div>

              {/* Options list */}
              <div className="flex flex-col gap-2">
                {/* Option 1: Casuale 1, 2 o 3 */}
                <button
                  type="button"
                  onClick={() => {
                    setImagePanelPosition(image.id, 'random');
                    setIsPositionModalOpen(false);
                  }}
                  className={`p-2 rounded-lg border flex items-start gap-2 cursor-pointer transition-all text-left ${
                    targetPanel === 'random'
                      ? 'bg-fuchsia-950/70 border-fuchsia-500 shadow-md shadow-fuchsia-900/30 ring-1 ring-fuchsia-400'
                      : 'bg-gray-950/70 border-gray-800 hover:border-fuchsia-500/50 hover:bg-gray-800'
                  }`}
                >
                  <span className="text-lg mt-0.5 shrink-0">🎲</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">Posizione Casuale (1, 2 o 3)</span>
                      {targetPanel === 'random' && (
                        <span className="text-[9px] bg-fuchsia-600 text-white px-1.5 py-0.2 rounded font-bold shrink-0 ml-1">Attiva</span>
                      )}
                    </div>
                    <p className="text-[10px] text-gray-400 mt-0.5 leading-tight">
                      Compare a sorpresa in una delle altre 2 posizioni (<strong>scartando la posizione attesa</strong>).
                    </p>
                  </div>
                </button>

                {/* Option 2: Sinistra (1) */}
                <button
                  type="button"
                  onClick={() => {
                    setImagePanelPosition(image.id, 'left');
                    setIsPositionModalOpen(false);
                  }}
                  className={`p-2 rounded-lg border flex items-start gap-2 cursor-pointer transition-all text-left ${
                    targetPanel === 'left'
                      ? 'bg-blue-950/70 border-blue-500 shadow-md shadow-blue-900/30 ring-1 ring-blue-400'
                      : 'bg-gray-950/70 border-gray-800 hover:border-blue-500/50 hover:bg-gray-800'
                  }`}
                >
                  <span className="text-lg mt-0.5 shrink-0">◀</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">Posizione 1: Sinistra</span>
                      {targetPanel === 'left' && (
                        <span className="text-[9px] bg-blue-600 text-white px-1.5 py-0.2 rounded font-bold shrink-0 ml-1">Attiva</span>
                      )}
                    </div>
                    <p className="text-[10px] text-gray-400 mt-0.5 leading-tight">
                      Compare sempre nel pannello di sinistra.
                    </p>
                  </div>
                </button>

                {/* Option 3: Centro (2) */}
                <button
                  type="button"
                  onClick={() => {
                    setImagePanelPosition(image.id, 'center');
                    setIsPositionModalOpen(false);
                  }}
                  className={`p-2 rounded-lg border flex items-start gap-2 cursor-pointer transition-all text-left ${
                    targetPanel === 'center'
                      ? 'bg-emerald-950/70 border-emerald-500 shadow-md shadow-emerald-900/30 ring-1 ring-emerald-400'
                      : 'bg-gray-950/70 border-gray-800 hover:border-emerald-500/50 hover:bg-gray-800'
                  }`}
                >
                  <span className="text-lg mt-0.5 shrink-0">●</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">Posizione 2: Centro</span>
                      {targetPanel === 'center' && (
                        <span className="text-[9px] bg-emerald-600 text-white px-1.5 py-0.2 rounded font-bold shrink-0 ml-1">Attiva</span>
                      )}
                    </div>
                    <p className="text-[10px] text-gray-400 mt-0.5 leading-tight">
                      Compare sempre nel pannello centrale.
                    </p>
                  </div>
                </button>

                {/* Option 4: Destra (3) */}
                <button
                  type="button"
                  onClick={() => {
                    setImagePanelPosition(image.id, 'right');
                    setIsPositionModalOpen(false);
                  }}
                  className={`p-2 rounded-lg border flex items-start gap-2 cursor-pointer transition-all text-left ${
                    targetPanel === 'right'
                      ? 'bg-purple-950/70 border-purple-500 shadow-md shadow-purple-900/30 ring-1 ring-purple-400'
                      : 'bg-gray-950/70 border-gray-800 hover:border-purple-500/50 hover:bg-gray-800'
                  }`}
                >
                  <span className="text-lg mt-0.5 shrink-0">▶</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">Posizione 3: Destra</span>
                      {targetPanel === 'right' && (
                        <span className="text-[9px] bg-purple-600 text-white px-1.5 py-0.2 rounded font-bold shrink-0 ml-1">Attiva</span>
                      )}
                    </div>
                    <p className="text-[10px] text-gray-400 mt-0.5 leading-tight">
                      Compare sempre nel pannello di destra.
                    </p>
                  </div>
                </button>

                {/* Option 5: Predefinita / Qualsiasi */}
                <button
                  type="button"
                  onClick={() => {
                    setImagePanelPosition(image.id, 'any');
                    setIsPositionModalOpen(false);
                  }}
                  className={`p-2 rounded-lg border flex items-start gap-2 cursor-pointer transition-all text-left ${
                    targetPanel === 'any'
                      ? 'bg-gray-800 border-gray-600 shadow ring-1 ring-gray-400'
                      : 'bg-gray-950/70 border-gray-800 hover:border-gray-700 hover:bg-gray-800'
                  }`}
                >
                  <span className="text-lg mt-0.5 shrink-0">🔄</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">Rotazione Predefinita</span>
                      {targetPanel === 'any' && (
                        <span className="text-[9px] bg-gray-600 text-white px-1.5 py-0.2 rounded font-bold shrink-0 ml-1">Attiva</span>
                      )}
                    </div>
                    <p className="text-[10px] text-gray-400 mt-0.5 leading-tight">
                      Segue il normale flusso continuo ordinato da sinistra verso destra.
                    </p>
                  </div>
                </button>
              </div>
            </div>

            {/* Footer - Fixed at bottom */}
            <div className="flex items-center justify-end px-4 py-2 border-t border-gray-800 shrink-0 bg-gray-900/95">
              <button
                type="button"
                onClick={() => setIsPositionModalOpen(false)}
                className="py-1 px-3 text-xs text-gray-400 hover:text-white cursor-pointer transition-colors"
              >
                Chiudi
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
