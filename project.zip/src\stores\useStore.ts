import { create } from 'zustand';
import { GalleryImage, SlideshowSettings, TriptychState, AlbumData, PanelPosition, AudioTrack, AudioSettings } from '../types';
import { convertFileSrc, invoke } from '@tauri-apps/api/core';
import { open, save } from '@tauri-apps/plugin-dialog';

interface AppState {
  // Gallery
  images: GalleryImage[];
  addImages: (paths: string[]) => Promise<void>;
  removeImage: (id: string) => void;
  reorderImages: (fromIndex: number, toIndex: number) => void;
  setPairedImage: (imageId: string, pairedId: string | null) => void;
  setImagePanelPosition: (imageId: string, position: PanelPosition) => void;
  setImageCustomDuration: (imageId: string, duration?: number) => void;
  clearImages: () => void;

  // Slideshow
  isPlaying: boolean;
  shuffledOrder: number[];
  settings: SlideshowSettings;
  triptych: TriptychState;
  setPlaying: (playing: boolean) => void;
  togglePlay: () => void;
  updateSettings: (settings: Partial<SlideshowSettings>) => void;
  advanceSlideshow: () => void;
  resetSlideshow: () => void;
  initSlideshow: () => void;

  // Active Tab
  activeTab: 'images' | 'audio';
  setActiveTab: (tab: 'images' | 'audio') => void;

  // Audio
  audioTracks: AudioTrack[];
  audioSettings: AudioSettings;
  currentAudioIndex: number;
  previewAudioId: string | null;
  shuffledAudioOrder: number[];
  audioShuffleIndex: number;
  addAudioTracks: (paths: string[]) => Promise<void>;
  removeAudioTrack: (id: string) => void;
  reorderAudioTracks: (fromIndex: number, toIndex: number) => void;
  clearAudioTracks: () => void;
  updateAudioSettings: (settings: Partial<AudioSettings>) => void;
  setCurrentAudioIndex: (index: number) => void;
  setPreviewAudio: (id: string | null) => void;
  nextAudioTrack: () => void;
  previousAudioTrack: () => void;

  // Projection & Fullscreen Preview
  isProjectionOpen: boolean;
  setProjectionOpen: (open: boolean) => void;
  isFullPreviewOpen: boolean;
  setFullPreviewOpen: (open: boolean) => void;

  // Albums
  savedAlbums: AlbumData[];
  currentAlbumId: string | null;
  currentAlbumName: string;
  isAlbumModalOpen: boolean;
  setAlbumModalOpen: (open: boolean) => void;
  setCurrentAlbumName: (name: string) => void;
  saveAlbum: (customName?: string) => Promise<string>;
  loadAlbum: (album: AlbumData) => Promise<void>;
  deleteAlbum: (id: string) => void;
  renameAlbum: (id: string, newName: string) => void;
  newAlbum: () => void;
  exportAlbumToFile: () => Promise<boolean>;
  importAlbumFromFile: () => Promise<boolean>;
}

function shuffleArray(length: number): number[] {
  const arr = Array.from({ length }, (_, i) => i);
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function isSameAudioFile(t1?: AudioTrack | null, t2?: AudioTrack | null): boolean {
  if (!t1 || !t2) return false;
  if (t1.id === t2.id) return true;
  if (t1.path && t2.path && t1.path.toLowerCase() === t2.path.toLowerCase()) return true;
  if (t1.assetUrl && t2.assetUrl && t1.assetUrl === t2.assetUrl) return true;
  if (t1.name && t2.name && t1.name.toLowerCase() === t2.name.toLowerCase()) return true;
  return false;
}

const STORAGE_KEY = 'triptych_saved_albums_v1';

function getInitialSavedAlbums(): AlbumData[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error reading saved albums from localStorage:', e);
  }
  return [];
}

function persistSavedAlbums(albums: AlbumData[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(albums));
  } catch (e) {
    console.error('Error persisting saved albums:', e);
  }
}

export const useStore = create<AppState>((set, get) => ({
  // Gallery state
  images: [],
  
  addImages: async (paths: string[]) => {
    const newImages: GalleryImage[] = await Promise.all(
      paths.map(async (p) => {
        const name = p.split('\\').pop()?.split('/').pop() || 'image';
        let assetUrl = convertFileSrc(p);
        try {
          const b64 = await invoke<string>('read_image_base64', { path: p });
          if (b64) {
            assetUrl = b64;
          }
        } catch (e) {
          console.warn('read_image_base64 fallback:', e);
        }
        return {
          id: crypto.randomUUID(),
          path: p,
          assetUrl,
          name,
        };
      })
    );
    set((state) => ({ images: [...state.images, ...newImages] }));
  },

  setPairedImage: (imageId: string, pairedId: string | null) => {
    set((state) => ({
      images: state.images.map((img) =>
        img.id === imageId ? { ...img, pairedImageId: pairedId || undefined } : img
      ),
    }));
  },

  setImagePanelPosition: (imageId: string, position: PanelPosition) => {
    set((state) => ({
      images: state.images.map((img) =>
        img.id === imageId ? { ...img, targetPanel: position } : img
      ),
    }));
  },

  setImageCustomDuration: (imageId: string, duration?: number) => {
    set((state) => ({
      images: state.images.map((img) =>
        img.id === imageId ? { ...img, customDuration: duration && duration > 0 ? duration : undefined } : img
      ),
    }));
  },

  removeImage: (id: string) => {
    set((state) => ({
      images: state.images
        .filter((img) => img.id !== id)
        .map((img) => (img.pairedImageId === id ? { ...img, pairedImageId: undefined } : img)),
    }));
  },

  reorderImages: (fromIndex: number, toIndex: number) => {
    set((state) => {
      const newImages = [...state.images];
      const [moved] = newImages.splice(fromIndex, 1);
      newImages.splice(toIndex, 0, moved);
      return { images: newImages };
    });
  },

  clearImages: () => set({ images: [] }),

  // Active tab state
  activeTab: 'images',
  setActiveTab: (tab: 'images' | 'audio') => set({ activeTab: tab }),

  // Audio state
  audioTracks: [],
  audioSettings: {
    enabled: true,
    mode: 'sequential',
    volume: 1.0,
    continuous: true,
  },
  currentAudioIndex: 0,
  previewAudioId: null,
  shuffledAudioOrder: [] as number[],
  audioShuffleIndex: 0,

  addAudioTracks: async (paths: string[]) => {
    const newTracks: AudioTrack[] = paths.map((p) => {
      const name = p.split('\\').pop()?.split('/').pop() || 'audio';
      const assetUrl = convertFileSrc(p);
      return {
        id: crypto.randomUUID(),
        path: p,
        assetUrl,
        name,
      };
    });
    set((state) => ({
      audioTracks: [...state.audioTracks, ...newTracks],
      shuffledAudioOrder: [],
      audioShuffleIndex: 0,
    }));
  },

  removeAudioTrack: (id: string) => {
    set((state) => {
      const remaining = state.audioTracks.filter((t) => t.id !== id);
      const newIdx =
        state.currentAudioIndex >= remaining.length
          ? Math.max(0, remaining.length - 1)
          : state.currentAudioIndex;
      return {
        audioTracks: remaining,
        currentAudioIndex: newIdx,
        previewAudioId: state.previewAudioId === id ? null : state.previewAudioId,
        shuffledAudioOrder: [],
        audioShuffleIndex: 0,
      };
    });
  },

  reorderAudioTracks: (fromIndex: number, toIndex: number) => {
    set((state) => {
      const newTracks = [...state.audioTracks];
      const [moved] = newTracks.splice(fromIndex, 1);
      newTracks.splice(toIndex, 0, moved);
      return {
        audioTracks: newTracks,
        shuffledAudioOrder: [],
        audioShuffleIndex: 0,
      };
    });
  },

  clearAudioTracks: () =>
    set({
      audioTracks: [],
      currentAudioIndex: 0,
      previewAudioId: null,
      shuffledAudioOrder: [],
      audioShuffleIndex: 0,
    }),

  updateAudioSettings: (newSettings: Partial<AudioSettings>) => {
    set((state) => ({
      audioSettings: { ...state.audioSettings, ...newSettings },
    }));
  },

  setCurrentAudioIndex: (index: number) => set({ currentAudioIndex: index }),

  setPreviewAudio: (id: string | null) => set({ previewAudioId: id }),

  nextAudioTrack: () => {
    const { audioTracks, audioSettings, currentAudioIndex } = get();
    if (audioTracks.length === 0) return;
    if (audioTracks.length === 1) {
      set({ currentAudioIndex: 0 });
      return;
    }

    const currentTrack = audioTracks[currentAudioIndex] || null;

    // Check how many distinct audio files exist
    const distinctFiles = new Set(
      audioTracks.map((t) => (t.path ? t.path.toLowerCase() : t.assetUrl || t.name.toLowerCase()))
    );
    const hasMultipleDistinct = distinctFiles.size >= 2;

    if (audioSettings.mode === 'shuffle') {
      let order = [...(get().shuffledAudioOrder || [])];
      let orderIndex = get().audioShuffleIndex ?? 0;

      // Initialize or rebuild deck if needed
      if (!order || order.length !== audioTracks.length) {
        order = shuffleArray(audioTracks.length);
        orderIndex = 0;
      }

      // If we reached the end of the current shuffle cycle
      if (orderIndex >= order.length) {
        order = shuffleArray(audioTracks.length);
        orderIndex = 0;

        // Ensure the first track of the new cycle is NOT the same file as the track just finished
        if (hasMultipleDistinct && isSameAudioFile(audioTracks[order[0]], currentTrack)) {
          const swapIdx = order.findIndex((idx) => !isSameAudioFile(audioTracks[idx], currentTrack));
          if (swapIdx !== -1) {
            const tmp = order[0];
            order[0] = order[swapIdx];
            order[swapIdx] = tmp;
          }
        }
      }

      // Check if candidate at current orderIndex is the same file as currentTrack
      if (hasMultipleDistinct && isSameAudioFile(audioTracks[order[orderIndex]], currentTrack)) {
        // Find the next track in the remaining deck that is a different file
        const diffOffset = order.slice(orderIndex).findIndex((idx) => !isSameAudioFile(audioTracks[idx], currentTrack));
        if (diffOffset !== -1) {
          const target = orderIndex + diffOffset;
          const tmp = order[orderIndex];
          order[orderIndex] = order[target];
          order[target] = tmp;
        } else {
          // All remaining in this cycle are duplicates of currentTrack, swap with any different file
          const anyDiffIdx = audioTracks.findIndex((t) => !isSameAudioFile(t, currentTrack));
          if (anyDiffIdx !== -1) {
            order[orderIndex] = anyDiffIdx;
          }
        }
      }

      const nextTrackIdx = order[orderIndex];
      set({
        currentAudioIndex: nextTrackIdx,
        shuffledAudioOrder: order,
        audioShuffleIndex: orderIndex + 1,
      });
    } else {
      // Sequential mode: find next track that is a DIFFERENT file
      let nextIdx = (currentAudioIndex + 1) % audioTracks.length;

      if (hasMultipleDistinct && currentTrack) {
        for (let step = 1; step < audioTracks.length; step++) {
          const candIdx = (currentAudioIndex + step) % audioTracks.length;
          const candTrack = audioTracks[candIdx];
          if (!isSameAudioFile(candTrack, currentTrack)) {
            nextIdx = candIdx;
            break;
          }
        }
      }

      set({ currentAudioIndex: nextIdx });
    }
  },

  previousAudioTrack: () => {
    const { audioTracks, currentAudioIndex } = get();
    if (audioTracks.length === 0) return;
    if (audioTracks.length === 1) {
      set({ currentAudioIndex: 0 });
      return;
    }

    const currentTrack = audioTracks[currentAudioIndex] || null;
    const distinctFiles = new Set(
      audioTracks.map((t) => (t.path ? t.path.toLowerCase() : t.assetUrl || t.name.toLowerCase()))
    );
    const hasMultipleDistinct = distinctFiles.size >= 2;

    let prevIdx = (currentAudioIndex - 1 + audioTracks.length) % audioTracks.length;
    if (hasMultipleDistinct && currentTrack) {
      for (let step = 1; step < audioTracks.length; step++) {
        const candIdx = (currentAudioIndex - step + audioTracks.length * 2) % audioTracks.length;
        const candTrack = audioTracks[candIdx];
        if (!isSameAudioFile(candTrack, currentTrack)) {
          prevIdx = candIdx;
          break;
        }
      }
    }

    set({ currentAudioIndex: prevIdx });
  },

  // Slideshow state
  isPlaying: false,
  shuffledOrder: [] as number[],
  settings: {
    interval: 5,
    fadeDuration: 1000,
    fitMode: 'contain',
    mode: 'sequential',
    panelGap: 0,
    outerMargin: 0,
    playImages: true,
    continuous: true,
    projectionMode: 'single',
    leftMonitorIndex: 0,
    rightMonitorIndex: 1,
    centerOverlap: 0,
    edgeBlend: false,
  },
  triptych: {
    panels: [null, null, null],
    activePanel: 0,
    currentImageIndex: 0,
    pendingPairedImageId: null,
    lastChangedImageId: null,
    stepCount: 0,
    panelImageIds: [null, null, null],
    panelStartTimes: [0, 0, 0],
    panelDurations: [0, 0, 0],
  },

  setPlaying: (playing: boolean) => set({ isPlaying: playing }),

  togglePlay: () => {
    const { isPlaying, images, triptych } = get();
    if (!isPlaying) {
      if ((!triptych.panels[0] || !triptych.panels[1] || !triptych.panels[2]) && images.length > 0) {
        get().initSlideshow();
      }
      set({ isPlaying: true });
    } else {
      set({ isPlaying: false });
    }
  },

  updateSettings: (newSettings: Partial<SlideshowSettings>) => {
    set((state) => ({
      settings: { ...state.settings, ...newSettings },
    }));
  },

  initSlideshow: () => {
    const { images } = get();
    if (images.length === 0) return;

    // Track paths, URLs, and filenames already assigned to initial panels
    const usedIdentifiers = new Set<string>();

    const isImageUsed = (img: GalleryImage) =>
      usedIdentifiers.has(img.path) ||
      usedIdentifiers.has(img.assetUrl) ||
      (img.name ? usedIdentifiers.has(img.name) : false);

    const markImageUsed = (img: GalleryImage) => {
      if (img.path) usedIdentifiers.add(img.path);
      if (img.assetUrl) usedIdentifiers.add(img.assetUrl);
      if (img.name) usedIdentifiers.add(img.name);
    };

    const findInitialForPanel = (panelIdx: number): GalleryImage => {
      const posName: PanelPosition = panelIdx === 0 ? 'left' : panelIdx === 1 ? 'center' : 'right';

      // 1. Try an unused image assigned specifically to this panel
      let cand = images.find((img) => !isImageUsed(img) && img.targetPanel === posName);

      // 2. Try an unused image with 'any', 'random', or undefined targetPanel
      if (!cand) {
        cand = images.find((img) => !isImageUsed(img) && (!img.targetPanel || img.targetPanel === 'any' || img.targetPanel === 'random'));
      }

      // 3. Try ANY unused image in gallery
      if (!cand) {
        cand = images.find((img) => !isImageUsed(img));
      }

      // 4. Fallback only if the entire gallery has fewer than 3 distinct files
      if (!cand) {
        cand = images[panelIdx % images.length];
      }

      markImageUsed(cand);
      return cand;
    };

    const img0 = findInitialForPanel(0);
    const img1 = findInitialForPanel(1);
    const img2 = findInitialForPanel(2);

    const panels: [string | null, string | null, string | null] = [
      img0?.assetUrl || null,
      img1?.assetUrl || null,
      img2?.assetUrl || null,
    ];

    const now = Date.now();
    const panelImageIds: [string | null, string | null, string | null] = [
      img0?.id || null,
      img1?.id || null,
      img2?.id || null,
    ];
    const panelStartTimes: [number, number, number] = [now, now, now];
    const panelDurations: [number, number, number] = [
      img0?.customDuration && img0.customDuration > 0 ? img0.customDuration : 0,
      img1?.customDuration && img1.customDuration > 0 ? img1.customDuration : 0,
      img2?.customDuration && img2.customDuration > 0 ? img2.customDuration : 0,
    ];

    set({
      triptych: {
        panels,
        activePanel: 0,
        currentImageIndex: images.length > 3 ? 3 : 0,
        pendingPairedImageId: null,
        lastChangedImageId: img0?.id || null,
        stepCount: (get().triptych.stepCount || 0) + 1,
        panelImageIds,
        panelStartTimes,
        panelDurations,
      },
    });
  },

  advanceSlideshow: () => {
    const { images, triptych, settings } = get();
    if (images.length === 0) return;

    const now = Date.now();
    const currentStartTimes = triptych.panelStartTimes || [now, now, now];
    const currentDurations = triptych.panelDurations || [0, 0, 0];

    // A panel is locked if its current image has a custom duration and that duration has not yet expired
    const isPanelLocked = (p: 0 | 1 | 2) => {
      const targetSec = currentDurations[p];
      if (!targetSec || targetSec <= 0) return false;
      const elapsedSec = (now - currentStartTimes[p]) / 1000;
      return elapsedSec < targetSec;
    };

    let panelIndex: 0 | 1 | 2 = triptych.activePanel;
    let foundEligible = false;

    // Check starting from activePanel in left-to-right order (step 0, 1, 2)
    for (let step = 0; step < 3; step++) {
      const cand = ((triptych.activePanel + step) % 3) as 0 | 1 | 2;
      if (!isPanelLocked(cand)) {
        panelIndex = cand;
        foundEligible = true;
        break;
      }
    }

    if (!foundEligible) {
      // All panels are currently protected by their custom durations.
      // Do not change any image, just bump stepCount so the global timer continues ticking.
      set({
        triptych: {
          ...triptych,
          stepCount: (triptych.stepCount || 0) + 1,
        },
      });
      return;
    }

    const newPanels: [string | null, string | null, string | null] = [...triptych.panels];
    const currentPos: PanelPosition = panelIndex === 0 ? 'left' : panelIndex === 1 ? 'center' : 'right';

    // The other two panels currently showing on screen
    const otherPanel1 = (panelIndex + 1) % 3;
    const otherPanel2 = (panelIndex + 2) % 3;
    const otherUrl1 = newPanels[otherPanel1];
    const otherUrl2 = newPanels[otherPanel2];

    // Collect all identifiers (assetUrl, path, name) of images currently visible on the OTHER panels
    const visibleIdentifiers = new Set<string>();
    if (otherUrl1) visibleIdentifiers.add(otherUrl1);
    if (otherUrl2) visibleIdentifiers.add(otherUrl2);

    for (const img of images) {
      if (img.assetUrl === otherUrl1 || img.assetUrl === otherUrl2) {
        if (img.path) visibleIdentifiers.add(img.path);
        if (img.name) visibleIdentifiers.add(img.name);
      }
    }

    // A candidate image is STRICTLY FORBIDDEN if it is already displayed on any other panel
    const isAlreadyOnScreen = (img: GalleryImage) =>
      visibleIdentifiers.has(img.assetUrl) ||
      (img.path ? visibleIdentifiers.has(img.path) : false) ||
      (img.name ? visibleIdentifiers.has(img.name) : false);

    const isPosEligible = (img: GalleryImage) =>
      !img.targetPanel || img.targetPanel === 'any' || img.targetPanel === 'random' || img.targetPanel === currentPos;

    // Prefer transitioning to a different image than the one currently on this panel
    const isCurrentPanelImage = (img: GalleryImage) =>
      img.assetUrl === newPanels[panelIndex];

    let chosenImage: GalleryImage | null = null;
    let nextImageStoreIndex: number = triptych.currentImageIndex;
    let nextPendingPairedId: string | null = null;

    if (triptych.pendingPairedImageId) {
      const pairedImg = images.find((img) => img.id === triptych.pendingPairedImageId);
      if (pairedImg && !isAlreadyOnScreen(pairedImg)) {
        chosenImage = pairedImg;
        nextPendingPairedId = pairedImg.pairedImageId || null;
      }
    }

    if (!chosenImage) {
      if (settings.mode === 'shuffle') {
        let order = (get() as any).shuffledOrder as number[];
        if (!order || order.length !== images.length) {
          order = shuffleArray(images.length);
          set({ shuffledOrder: order } as any);
        }

        let foundIdx = -1;
        let foundOrderIdx = -1;

        // Pass 1: search in current shuffle order, not on screen, not current panel image, matches target panel
        for (let i = 0; i < order.length; i++) {
          const checkOrderIdx = (triptych.currentImageIndex + i) % order.length;
          const candidateImgIdx = order[checkOrderIdx];
          const cand = images[candidateImgIdx];
          if (cand && !isAlreadyOnScreen(cand) && !isCurrentPanelImage(cand) && isPosEligible(cand)) {
            foundIdx = candidateImgIdx;
            foundOrderIdx = checkOrderIdx;
            break;
          }
        }

        // Pass 2: not on screen, not current panel image
        if (foundIdx === -1) {
          for (let i = 0; i < order.length; i++) {
            const checkOrderIdx = (triptych.currentImageIndex + i) % order.length;
            const candidateImgIdx = order[checkOrderIdx];
            const cand = images[candidateImgIdx];
            if (cand && !isAlreadyOnScreen(cand) && !isCurrentPanelImage(cand)) {
              foundIdx = candidateImgIdx;
              foundOrderIdx = checkOrderIdx;
              break;
            }
          }
        }

        // Pass 3: any candidate not on other panels
        if (foundIdx === -1) {
          for (let i = 0; i < order.length; i++) {
            const checkOrderIdx = (triptych.currentImageIndex + i) % order.length;
            const candidateImgIdx = order[checkOrderIdx];
            const cand = images[candidateImgIdx];
            if (cand && !isAlreadyOnScreen(cand)) {
              foundIdx = candidateImgIdx;
              foundOrderIdx = checkOrderIdx;
              break;
            }
          }
        }

        // Fallback if gallery has fewer than 3 images
        if (foundIdx === -1) {
          foundOrderIdx = triptych.currentImageIndex % order.length;
          foundIdx = order[foundOrderIdx];
        }

        chosenImage = images[foundIdx];
        nextImageStoreIndex = (foundOrderIdx + 1) % order.length;

        // "nell'opsione casuale una volta mostrate tutte le foto lo slide ricomincia e continua senza fermarsi mai"
        // When the shuffled deck finishes, generate a new random shuffle and keep looping seamlessly
        if (nextImageStoreIndex === 0) {
          const newOrder = shuffleArray(images.length);
          set({ shuffledOrder: newOrder } as any);
        }
      } else {
        // Sequential mode (1 ➔ 2 ➔ 3...)
        // If single pass (continuous === false) and finished all photos, stop
        if (settings.continuous === false && triptych.currentImageIndex >= images.length) {
          set({ isPlaying: false });
          return;
        }

        let foundIdx = -1;

        // Pass 1: not on screen, not current panel image, matches target panel
        for (let i = 0; i < images.length; i++) {
          const checkIdx = (triptych.currentImageIndex + i) % images.length;
          const cand = images[checkIdx];
          if (!isAlreadyOnScreen(cand) && !isCurrentPanelImage(cand) && isPosEligible(cand)) {
            foundIdx = checkIdx;
            break;
          }
        }
        // Pass 2: not on screen, not current panel image, any panel
        if (foundIdx === -1) {
          for (let i = 0; i < images.length; i++) {
            const checkIdx = (triptych.currentImageIndex + i) % images.length;
            const cand = images[checkIdx];
            if (!isAlreadyOnScreen(cand) && !isCurrentPanelImage(cand)) {
              foundIdx = checkIdx;
              break;
            }
          }
        }
        // Pass 3: not on other panels (even if same as current panel)
        if (foundIdx === -1) {
          for (let i = 0; i < images.length; i++) {
            const checkIdx = (triptych.currentImageIndex + i) % images.length;
            const cand = images[checkIdx];
            if (!isAlreadyOnScreen(cand)) {
              foundIdx = checkIdx;
              break;
            }
          }
        }
        // Fallback only if gallery has fewer than 3 images
        if (foundIdx === -1) {
          foundIdx = triptych.currentImageIndex % images.length;
        }

        chosenImage = images[foundIdx];
        nextImageStoreIndex = (foundIdx + 1) % images.length;

        if (settings.continuous === false && foundIdx === images.length - 1) {
          nextImageStoreIndex = images.length;
        }
      }

      nextPendingPairedId = chosenImage.pairedImageId || null;
    }

    // If this image has targetPanel === 'random', place it randomly in one of the OTHER two positions,
    // discarding the expected panel where it would normally appear in the base slideshow rotation
    if (chosenImage.targetPanel === 'random') {
      const normalExpectedPanel = panelIndex;
      const otherPanels = ([0, 1, 2] as const).filter((p) => p !== normalExpectedPanel);

      const unlockedOthers = otherPanels.filter((p) => !isPanelLocked(p));
      const nonDuplicatingOthers = unlockedOthers.filter((p) => {
        const o1 = (p + 1) % 3;
        const o2 = (p + 2) % 3;
        return newPanels[o1] !== chosenImage.assetUrl && newPanels[o2] !== chosenImage.assetUrl;
      });

      const surpriseCandidates = nonDuplicatingOthers.length > 0 ? nonDuplicatingOthers : unlockedOthers;
      if (surpriseCandidates.length > 0) {
        panelIndex = surpriseCandidates[Math.floor(Math.random() * surpriseCandidates.length)];
      }
    }

    newPanels[panelIndex] = chosenImage.assetUrl;

    const newPanelImageIds: [string | null, string | null, string | null] = [
      ...(triptych.panelImageIds || [null, null, null]),
    ];
    const newPanelStartTimes: [number, number, number] = [
      ...(triptych.panelStartTimes || [now, now, now]),
    ];
    const newPanelDurations: [number, number, number] = [
      ...(triptych.panelDurations || [0, 0, 0]),
    ];

    newPanelImageIds[panelIndex] = chosenImage.id;
    newPanelStartTimes[panelIndex] = now;
    newPanelDurations[panelIndex] =
      chosenImage.customDuration && chosenImage.customDuration > 0
        ? chosenImage.customDuration
        : 0;

    const nextPanel = ((panelIndex + 1) % 3) as 0 | 1 | 2;

    set({
      triptych: {
        panels: newPanels,
        activePanel: nextPanel,
        currentImageIndex: nextImageStoreIndex,
        pendingPairedImageId: nextPendingPairedId,
        lastChangedImageId: chosenImage.id,
        stepCount: (triptych.stepCount || 0) + 1,
        panelImageIds: newPanelImageIds,
        panelStartTimes: newPanelStartTimes,
        panelDurations: newPanelDurations,
      },
    });
  },

  resetSlideshow: () => {
    set({
      isPlaying: false,
      triptych: {
        panels: [null, null, null],
        activePanel: 0,
        currentImageIndex: 0,
        pendingPairedImageId: null,
        lastChangedImageId: null,
        stepCount: 0,
        panelImageIds: [null, null, null],
        panelStartTimes: [0, 0, 0],
        panelDurations: [0, 0, 0],
      },
    });
  },

  // Projection & Fullscreen Preview
  isProjectionOpen: false,
  setProjectionOpen: (open: boolean) => set({ isProjectionOpen: open }),
  isFullPreviewOpen: false,
  setFullPreviewOpen: (open: boolean) => set({ isFullPreviewOpen: open }),

  // Albums
  savedAlbums: getInitialSavedAlbums(),
  currentAlbumId: null,
  currentAlbumName: 'Nuovo Album',
  isAlbumModalOpen: false,
  setAlbumModalOpen: (open: boolean) => set({ isAlbumModalOpen: open }),
  setCurrentAlbumName: (name: string) => set({ currentAlbumName: name }),

  saveAlbum: async (customName?: string) => {
    const { images, audioTracks, audioSettings, settings, currentAlbumId, currentAlbumName, savedAlbums } = get();
    const finalName = (customName || currentAlbumName || 'Mio Album').trim();
    const albumId = currentAlbumId || crypto.randomUUID();
    const now = new Date().toISOString();

    const existingAlbum = savedAlbums.find((a) => a.id === albumId);
    const albumData: AlbumData = {
      id: albumId,
      name: finalName,
      createdAt: existingAlbum ? existingAlbum.createdAt : now,
      updatedAt: now,
      images: images.map((img) => ({
        id: img.id,
        path: img.path,
        name: img.name,
        pairedImageId: img.pairedImageId,
        targetPanel: img.targetPanel,
        customDuration: img.customDuration,
      })),
      audioTracks: audioTracks.map((t) => ({
        id: t.id,
        path: t.path,
        name: t.name,
      })),
      audioSettings: { ...audioSettings },
      settings: { ...settings },
    };

    const existingIndex = savedAlbums.findIndex((a) => a.id === albumId);
    let newSaved: AlbumData[];
    if (existingIndex >= 0) {
      newSaved = [...savedAlbums];
      newSaved[existingIndex] = albumData;
    } else {
      newSaved = [albumData, ...savedAlbums];
    }

    persistSavedAlbums(newSaved);
    set({
      savedAlbums: newSaved,
      currentAlbumId: albumId,
      currentAlbumName: finalName,
    });
    return albumId;
  },

  loadAlbum: async (album: AlbumData) => {
    get().resetSlideshow();

    const loadedImages: GalleryImage[] = await Promise.all(
      album.images.map(async (img) => {
        let assetUrl = convertFileSrc(img.path);
        try {
          const b64 = await invoke<string>('read_image_base64', { path: img.path });
          if (b64) assetUrl = b64;
        } catch (e) {
          console.warn('read_image_base64 fallback:', e);
        }
        return {
          id: img.id,
          path: img.path,
          assetUrl,
          name: img.name,
          pairedImageId: img.pairedImageId,
          targetPanel: img.targetPanel,
          customDuration: img.customDuration,
        };
      })
    );

    const loadedAudio: AudioTrack[] = Array.isArray(album.audioTracks)
      ? album.audioTracks.map((t) => ({
          id: t.id,
          path: t.path,
          assetUrl: convertFileSrc(t.path),
          name: t.name,
        }))
      : [];

    set({
      images: loadedImages,
      audioTracks: loadedAudio,
      audioSettings: album.audioSettings || { enabled: true, mode: 'sequential', volume: 1.0 },
      currentAudioIndex: 0,
      settings: {
        ...get().settings,
        ...(album.settings || {}),
        mode: album.settings?.mode === 'shuffle' || album.settings?.mode === 'random' ? 'sequential' : (album.settings?.mode || 'sequential'),
        playImages: album.settings?.playImages ?? true,
      },
      currentAlbumId: album.id,
      currentAlbumName: album.name,
    });

    if (loadedImages.length > 0) {
      get().initSlideshow();
    }
  },

  deleteAlbum: (id: string) => {
    const { savedAlbums, currentAlbumId } = get();
    const newSaved = savedAlbums.filter((a) => a.id !== id);
    persistSavedAlbums(newSaved);
    set({
      savedAlbums: newSaved,
      ...(currentAlbumId === id ? { currentAlbumId: null, currentAlbumName: 'Nuovo Album' } : {}),
    });
  },

  renameAlbum: (id: string, newName: string) => {
    const { savedAlbums, currentAlbumId } = get();
    const newSaved = savedAlbums.map((a) =>
      a.id === id ? { ...a, name: newName.trim(), updatedAt: new Date().toISOString() } : a
    );
    persistSavedAlbums(newSaved);
    set({
      savedAlbums: newSaved,
      ...(currentAlbumId === id ? { currentAlbumName: newName.trim() } : {}),
    });
  },

  newAlbum: () => {
    get().resetSlideshow();
    set({
      images: [],
      audioTracks: [],
      currentAudioIndex: 0,
      previewAudioId: null,
      currentAlbumId: null,
      currentAlbumName: 'Nuovo Album',
    });
  },

  exportAlbumToFile: async () => {
    const { currentAlbumName, images, audioTracks, audioSettings, settings, currentAlbumId, savedAlbums } = get();
    const name = (currentAlbumName || 'Album').trim();
    const cleanFileName = name.replace(/[\\/:*?"<>|]/g, '_');
    const filePath = await save({
      defaultPath: `${cleanFileName}.triptych`,
      filters: [
        { name: 'Album Trittico (*.triptych)', extensions: ['triptych'] },
        { name: 'File JSON (*.json)', extensions: ['json'] },
      ],
    });
    if (!filePath) return false;

    const existingAlbum = currentAlbumId ? savedAlbums.find((a) => a.id === currentAlbumId) : null;
    const albumData: AlbumData = {
      id: currentAlbumId || crypto.randomUUID(),
      name,
      createdAt: existingAlbum ? existingAlbum.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      images: images.map((img) => ({
        id: img.id,
        path: img.path,
        name: img.name,
        pairedImageId: img.pairedImageId,
        targetPanel: img.targetPanel,
        customDuration: img.customDuration,
      })),
      audioTracks: audioTracks.map((t) => ({
        id: t.id,
        path: t.path,
        name: t.name,
      })),
      audioSettings: { ...audioSettings },
      settings: { ...settings },
    };

    await invoke('save_album_file', {
      path: filePath,
      content: JSON.stringify(albumData, null, 2),
    });
    return true;
  },

  importAlbumFromFile: async () => {
    const selected = await open({
      multiple: false,
      filters: [
        { name: 'Album Trittico (*.triptych, *.json)', extensions: ['triptych', 'json'] },
      ],
    });
    if (!selected || Array.isArray(selected)) return false;

    const content = await invoke<string>('read_album_file', { path: selected });
    const albumData = JSON.parse(content) as AlbumData;
    if (!albumData || !Array.isArray(albumData.images)) {
      throw new Error('File album non valido');
    }

    const { savedAlbums } = get();
    const existingIndex = savedAlbums.findIndex((a) => a.id === albumData.id);
    let newSaved: AlbumData[];
    if (existingIndex >= 0) {
      newSaved = [...savedAlbums];
      newSaved[existingIndex] = albumData;
    } else {
      newSaved = [albumData, ...savedAlbums];
    }
    persistSavedAlbums(newSaved);
    set({ savedAlbums: newSaved });

    await get().loadAlbum(albumData);
    return true;
  },
}));
