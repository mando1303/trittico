import { motion } from 'framer-motion';
import { useStore } from '../../stores/useStore';
import { WebviewWindow } from '@tauri-apps/api/webviewWindow';

interface FloatingControllerWindowProps {
  onClose: () => void;
  onExitPreview: () => void;
}

export default function FloatingControllerWindow({
  onClose,
  onExitPreview,
}: FloatingControllerWindowProps) {
  const isPlaying = useStore((s) => s.isPlaying);
  const togglePlay = useStore((s) => s.togglePlay);
  const resetSlideshow = useStore((s) => s.resetSlideshow);
  const advanceSlideshow = useStore((s) => s.advanceSlideshow);
  const triptych = useStore((s) => s.triptych);
  const settings = useStore((s) => s.settings);
  const images = useStore((s) => s.images);
  const audioTracks = useStore((s) => s.audioTracks);
  const audioSettings = useStore((s) => s.audioSettings);
  const updateAudioSettings = useStore((s) => s.updateAudioSettings);
  const updateSettings = useStore((s) => s.updateSettings);
  const currentAudioIndex = useStore((s) => s.currentAudioIndex);
  const nextAudioTrack = useStore((s) => s.nextAudioTrack);
  const previousAudioTrack = useStore((s) => s.previousAudioTrack);

  const currentTrack = audioTracks[currentAudioIndex] || null;
  const playImages = settings.playImages ?? true;
  const audioEnabled = audioSettings.enabled;

  const isImageContinua = settings.continuous ?? true;
  const isImageCasuale = settings.mode === 'shuffle';
  const isAudioContinua = audioSettings.continuous ?? true;
  const isAudioCasuale = audioSettings.mode === 'shuffle';

  const canPlayImages = playImages && images.length >= 1;
  const canPlayAudio = audioEnabled && audioTracks.length > 0;
  const canPlay = canPlayImages || canPlayAudio;

  const handleTogglePlay = () => {
    togglePlay();
  };

  const handleDetachWindow = async () => {
    try {
      const existing = await WebviewWindow.getByLabel('controller');
      if (existing) {
        await existing.show();
        await existing.setFocus();
        return;
      }

      const win = new WebviewWindow('controller', {
        url: '/?window=controller',
        title: 'Telecomando Triptych',
        width: 380,
        height: 380,
        resizable: false,
        alwaysOnTop: true,
        decorations: true,
      });

      win.once('tauri://error', (err) => {
        console.error('Error opening controller window:', err);
      });
    } catch (e) {
      console.warn('Could not open desktop controller window:', e);
    }
  };

  return (
    <motion.div
      drag
      dragMomentum={false}
      initial={{ opacity: 0, scale: 0.95, y: 15 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, y: 15 }}
      transition={{ duration: 0.18 }}
      className="fixed top-8 right-8 z-[100] w-80 bg-gray-900/95 text-white rounded-xl shadow-2xl border border-gray-700/80 backdrop-blur-md flex flex-col select-none overflow-hidden"
    >
      {/* Window Titlebar (Drag Handle) */}
      <div className="flex items-center justify-between px-3.5 py-2.5 bg-gray-800/90 border-b border-gray-700/70 cursor-move">
        <div className="flex items-center gap-2">
          <span className="text-gray-400 text-sm">⠿</span>
          <span className="text-xs font-bold tracking-wide text-gray-200">
            🎬 Telecomando Slideshow
          </span>
        </div>

        <div className="flex items-center gap-1.5" onPointerDown={(e) => e.stopPropagation()}>
          <button
            onClick={handleDetachWindow}
            className="p-1 text-gray-400 hover:text-blue-400 hover:bg-gray-700 rounded transition-colors cursor-pointer"
            title="Stacca in finestra desktop indipendente"
          >
            <span className="text-xs">⧉</span>
          </button>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-white hover:bg-gray-700 rounded transition-colors cursor-pointer"
            title="Chiudi finestra controlli (premi C per riaprirla)"
          >
            <span className="text-xs font-bold leading-none">✕</span>
          </button>
        </div>
      </div>

      {/* Window Body */}
      <div className="p-4 flex flex-col gap-3" onPointerDown={(e) => e.stopPropagation()}>
        {/* Playback Status & Mode info */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span
              className={`w-2 h-2 rounded-full ${
                isPlaying ? 'bg-green-500 animate-pulse' : 'bg-yellow-500'
              }`}
            />
            <span className="text-xs font-semibold text-gray-300">
              {isPlaying ? 'In Riproduzione' : 'In Pausa'}
            </span>
          </div>

          <span className="text-[11px] text-gray-400">
            Sinistra ➔ Destra • {settings.interval}s
          </span>
        </div>

        {/* Panel Indicators */}
        <div className="bg-gray-950/60 p-2.5 rounded-lg border border-gray-800">
          <div className="text-[10px] text-gray-400 uppercase tracking-wider mb-1.5 font-semibold text-center">
            Prossimo pannello che cambia
          </div>
          <div className="grid grid-cols-3 gap-1.5 text-center">
            {[
              { idx: 0, label: '1 • Sin' },
              { idx: 1, label: '2 • Cen' },
              { idx: 2, label: '3 • Des' },
            ].map((p) => {
              const isActive = triptych.activePanel === p.idx;
              return (
                <div
                  key={p.idx}
                  className={`py-1 px-1 rounded text-[11px] font-medium transition-all ${
                    isActive
                      ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-500/30 ring-1 ring-blue-400'
                      : 'bg-gray-800/80 text-gray-400 border border-gray-700/50'
                  }`}
                >
                  {p.label}
                </div>
              );
            })}
          </div>
        </div>

        {/* Background Audio info */}
        {audioTracks.length > 0 && (
          <div className="bg-gray-950/60 p-2 rounded-lg border border-gray-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 min-w-0 flex-1 mr-2">
              <span
                className={`text-sm ${
                  isPlaying && audioSettings.enabled
                    ? 'animate-pulse text-emerald-400'
                    : 'text-gray-500'
                }`}
              >
                🎵
              </span>
              <div className="flex flex-col min-w-0 flex-1">
                <span className="text-[11px] text-gray-200 font-medium truncate" title={currentTrack?.name || ''}>
                  {audioSettings.enabled
                    ? currentTrack
                      ? currentTrack.name
                      : 'Nessuna traccia'
                    : 'Audio disattivato'}
                </span>
                <span className="text-[9px] text-gray-400">
                  {audioSettings.mode === 'sequential' ? 'Continua' : 'Casuale'} • {Math.round(audioSettings.volume * 100)}%
                </span>
              </div>
            </div>

            {audioSettings.enabled && (
              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => previousAudioTrack()}
                  className="px-1.5 py-1 text-[10px] bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white rounded border border-gray-700 cursor-pointer transition-colors"
                  title="Brano precedente"
                >
                  ⏮
                </button>
                <button
                  onClick={() => nextAudioTrack()}
                  className="px-1.5 py-1 text-[10px] bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white rounded border border-gray-700 cursor-pointer transition-colors"
                  title="Passa al prossimo brano audio"
                >
                  ⏭
                </button>
              </div>
            )}
          </div>
        )}

        {/* Modalità con Spunte (Immagini & Audio) */}
        <div className="bg-gray-950/70 p-2.5 rounded-lg border border-gray-800 flex flex-col gap-2">
          {/* Immagini */}
          <div>
            <div className="flex items-center justify-between text-[11px] mb-1">
              <label className="flex items-center gap-1.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={playImages}
                  onChange={(e) => updateSettings({ playImages: e.target.checked })}
                  className="rounded accent-blue-500 cursor-pointer w-3.5 h-3.5"
                />
                <span className="font-semibold text-gray-200">📷 Immagini</span>
              </label>
              <span className="text-[10px] text-gray-400">{images.length} foto</span>
            </div>
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between bg-blue-900/25 border border-blue-800/40 rounded px-2 py-1 text-[11px] text-blue-200">
                <span className="flex items-center gap-1 font-medium">
                  <span>➡️</span>
                  <span>Sinistra ➔ Destra</span>
                </span>
                <span className="text-[9px] text-blue-300/80 font-normal">Fissa</span>
              </div>

              <div className="grid grid-cols-2 gap-1.5">
                <label className={`flex items-center gap-1.5 px-2 py-1.5 rounded text-[11px] cursor-pointer border select-none transition-colors ${
                  isImageContinua
                    ? 'bg-blue-600/30 border-blue-500 text-white font-medium'
                    : 'bg-gray-900 border-gray-800 text-gray-400 hover:text-gray-200'
                }`}>
                  <input
                    type="checkbox"
                    checked={isImageContinua}
                    onChange={(e) => updateSettings({ continuous: e.target.checked })}
                    className="rounded accent-blue-500 cursor-pointer w-3.5 h-3.5"
                  />
                  <span>🔄 Continua</span>
                </label>

                <label className={`flex items-center gap-1.5 px-2 py-1.5 rounded text-[11px] cursor-pointer border select-none transition-colors ${
                  isImageCasuale
                    ? 'bg-blue-600/30 border-blue-500 text-white font-medium'
                    : 'bg-gray-900 border-gray-800 text-gray-400 hover:text-gray-200'
                }`}>
                  <input
                    type="checkbox"
                    checked={isImageCasuale}
                    onChange={(e) => updateSettings({ mode: e.target.checked ? 'shuffle' : 'sequential' })}
                    className="rounded accent-blue-500 cursor-pointer w-3.5 h-3.5"
                  />
                  <span>🔀 Casuale</span>
                </label>
              </div>
            </div>
            <div className="mt-1 text-[9px] text-center text-blue-300/80">
              {!playImages
                ? 'Disattivata'
                : isImageCasuale && isImageContinua
                ? '✨ Casuale + Continua'
                : isImageCasuale
                ? '🔀 Casuale (ricomincia sempre)'
                : isImageContinua
                ? '🔄 Continua ordinata (loop)'
                : '➡️ Singola passata'}
            </div>
          </div>

          {/* Audio */}
          <div className="border-t border-gray-850 pt-2">
            <div className="flex items-center justify-between text-[11px] mb-1">
              <label className="flex items-center gap-1.5 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={audioEnabled}
                  onChange={(e) => updateAudioSettings({ enabled: e.target.checked })}
                  className="rounded accent-emerald-500 cursor-pointer w-3.5 h-3.5"
                />
                <span className="font-semibold text-gray-200">🎵 Audio / Musica</span>
              </label>
              <span className="text-[10px] text-gray-400">{audioTracks.length} tracce</span>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              <label className={`flex items-center gap-1.5 px-2 py-1.5 rounded text-[11px] cursor-pointer border select-none transition-colors ${
                isAudioContinua
                  ? 'bg-emerald-600/30 border-emerald-500 text-white font-medium'
                  : 'bg-gray-900 border-gray-800 text-gray-400 hover:text-gray-200'
              }`}>
                <input
                  type="checkbox"
                  checked={isAudioContinua}
                  onChange={(e) => updateAudioSettings({ continuous: e.target.checked })}
                  className="rounded accent-emerald-500 cursor-pointer w-3.5 h-3.5"
                />
                <span>🔄 Continua</span>
              </label>
              <label className={`flex items-center gap-1.5 px-2 py-1.5 rounded text-[11px] cursor-pointer border select-none transition-colors ${
                isAudioCasuale
                  ? 'bg-emerald-600/30 border-emerald-500 text-white font-medium'
                  : 'bg-gray-900 border-gray-800 text-gray-400 hover:text-gray-200'
              }`}>
                <input
                  type="checkbox"
                  checked={isAudioCasuale}
                  onChange={(e) => updateAudioSettings({ mode: e.target.checked ? 'shuffle' : 'sequential' })}
                  className="rounded accent-emerald-500 cursor-pointer w-3.5 h-3.5"
                />
                <span>🔀 Casuale</span>
              </label>
            </div>
            <div className="mt-1 text-[9px] text-center text-emerald-300/80">
              {!audioEnabled
                ? 'Disattivato'
                : isAudioContinua && isAudioCasuale
                ? '✨ Casuale e Continua insieme'
                : isAudioContinua
                ? '🔄 Continua ordinata'
                : isAudioCasuale
                ? '🔀 Casuale singola'
                : '⏸ Nessuna modalità'}
            </div>
          </div>
        </div>

        {/* Main Controls */}
        <div className="flex flex-col gap-2">
          <button
            onClick={handleTogglePlay}
            disabled={!canPlay}
            className={`w-full py-2.5 rounded-lg text-sm font-bold cursor-pointer transition-all shadow ${
              isPlaying
                ? 'bg-yellow-600 hover:bg-yellow-500 text-white'
                : 'bg-gray-700 hover:bg-gray-600 text-white border border-gray-600'
            } disabled:opacity-40 disabled:cursor-not-allowed`}
          >
            {isPlaying ? '⏸ Metti in Pausa (Spazio)' : '▶ Avvia Slideshow (Spazio)'}
          </button>

          <div className="flex gap-2">
            <button
              onClick={() => advanceSlideshow()}
              disabled={!canPlay}
              className="flex-1 py-2 bg-gray-700 hover:bg-gray-600 text-white text-xs font-semibold rounded-lg cursor-pointer transition-colors shadow flex items-center justify-center gap-1.5 disabled:opacity-40"
              title="Avanza manualmente al prossimo pannello (tasto →)"
            >
              <span>⏭</span>
              <span>Avanza</span>
            </button>

            <button
              onClick={() => resetSlideshow()}
              className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white text-xs font-semibold rounded-lg border border-gray-700 cursor-pointer transition-colors"
              title="Stop e azzera sequenza"
            >
              ⏹ Stop
            </button>
          </div>
        </div>

        {/* Shortcuts reminder */}
        <div className="text-[10px] text-gray-400 bg-gray-800/40 px-2 py-1.5 rounded border border-gray-800/80 flex justify-between items-center">
          <span>Tasto <strong>C</strong>: mostra/nascondi</span>
          <span><strong>Esc</strong>: esci</span>
        </div>

        {/* Exit Preview Button */}
        <button
          onClick={onExitPreview}
          className="w-full py-1.5 bg-red-600/70 hover:bg-red-600 text-white text-xs font-semibold rounded cursor-pointer transition-colors"
        >
          ✕ Chiudi Anteprima
        </button>
      </div>
    </motion.div>
  );
}
