import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import ProjectionApp from './ProjectionApp';
import ControlsWindowApp from './ControlsWindowApp';
import ControllerApp from './ControllerApp';
import './index.css';

// Determine which window we are in based on URL search params
const params = new URLSearchParams(window.location.search);
const windowType = params.get('window');

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    {windowType === 'projection' ? (
      <ProjectionApp />
    ) : windowType === 'controls' ? (
      <ControlsWindowApp />
    ) : windowType === 'controller' ? (
      <ControllerApp />
    ) : (
      <App />
    )}
  </React.StrictMode>
);
