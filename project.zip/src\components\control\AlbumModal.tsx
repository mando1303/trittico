import { useState } from 'react';
import { useStore } from '../../stores/useStore';
import { AlbumData } from '../../types';

export default function AlbumModal() {
  const isAlbumModalOpen = useStore((s) => s.isAlbumModalOpen);
  const setAlbumModalOpen = useStore((s) => s.setAlbumModalOpen);
  const savedAlbums = useStore((s) => s.savedAlbums);
  const currentAlbumId = useStore((s) => s.currentAlbumId);
  const currentAlbumName = useStore((s) => s.currentAlbumName);
  const setCurrentAlbumName = useStore((s) => s.setCurrentAlbumName);
  const images = useStore((s) => s.images);
  const settings = useStore((s) => s.settings);

  const saveAlbum = useStore((s) => s.saveAlbum);
  const loadAlbum = useStore((s) => s.loadAlbum);
  const deleteAlbum = useStore((s) => s.deleteAlbum);
  const renameAlbum = useStore((s) => s.renameAlbum);
  const newAlbum = useStore((s) => s.newAlbum);
  const exportAlbumToFile = useStore((s) => s.exportAlbumToFile);
  const importAlbumFromFile = useStore((s) => s.importAlbumFromFile);

  const [albumNameInput, setAlbumNameInput] = useState('');
  const [editingAlbumId, setEditingAlbumId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const [notification, setNotification] = useState<string | null>(null);

  if (!isAlbumModalOpen) return null;

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const handleSaveCurrent = async () => {
    const nameToSave = albumNameInput.trim() || currentAlbumName.trim() || 'Mio Album';
    await saveAlbum(nameToSave);
    setAlbumNameInput('');
    showToast(`Album "${nameToSave}" salvato con successo!`);
  };

  const handleLoad = async (album: AlbumData) => {
    await loadAlbum(album);
    showToast(`Album "${album.name}" caricato!`);
    setAlbumModalOpen(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Sei sicuro di voler eliminare l'album "${name}"?`)) {
      deleteAlbum(id);
      showToast(`Album "${name}" eliminato.`);
    }
  };

  const handleStartRename = (album: AlbumData) => {
    setEditingAlbumId(album.id);
    setEditingName(album.name);
  };

  const handleSaveRename = (id: string) => {
    if (editingName.trim()) {
      renameAlbum(id, editingName.trim());
      setEditingAlbumId(null);
      showToast(`Album rinominato in "${editingName.trim()}".`);
    }
  };

  const handleExport = async () => {
    try {
      const exported = await exportAlbumToFile();
      if (exported) {
        showToast('Album esportato su file con successo!');
      }
    } catch (e) {
      console.error(e);
      showToast('Errore durante il salvataggio del file.');
    }
  };

  const handleImport = async () => {
    try {
      const imported = await importAlbumFromFile();
      if (imported) {
        showToast('Album importato con successo!');
        setAlbumModalOpen(false);
      }
    } catch (e) {
      console.error(e);
      showToast('Errore durante il caricamento del file album.');
    }
  };

  const handleNewAlbum = () => {
    if (images.length > 0) {
      if (!window.confirm('Vuoi iniziare un nuovo album? La galleria attuale verrà azzerata.')) {
        return;
      }
    }
    newAlbum();
    showToast('Nuovo album creato. Puoi inserire nuove immagini!');
    setAlbumModalOpen(false);
  };

  const formatDate = (iso: string) => {
    try {
      const d = new Date(iso);
      return d.toLocaleDateString('it-IT', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return iso;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-gray-900 border border-gray-700 w-full max-w-3xl rounded-xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden text-white animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800 bg-gray-800/40">
          <div className="flex items-center gap-2">
            <span className="text-xl">📁</span>
            <h2 className="text-lg font-bold text-gray-100">Gestione Album & Progetti</h2>
          </div>
          <button
            onClick={() => setAlbumModalOpen(false)}
            className="text-gray-400 hover:text-white text-lg px-2 py-1 rounded-md hover:bg-gray-800 cursor-pointer transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Notification Toast */}
        {notification && (
          <div className="bg-blue-600 text-white text-xs font-medium py-2 px-4 text-center animate-fade">
            {notification}
          </div>
        )}

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex flex-col gap-6 flex-1">
          {/* Current Album Section */}
          <div className="bg-gray-800/60 border border-gray-700/60 rounded-lg p-4 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">
                Album Attuale in Lavorazione
              </span>
              <span className="text-xs text-gray-400">
                {images.length} immagini • Intervallo {settings.interval}s • Sinistra ➔ Destra • Margine {settings.panelGap}px
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                placeholder="Nome dell'album (es. Vacanze 2026, Mostra...)"
                value={albumNameInput || currentAlbumName}
                onChange={(e) => {
                  setAlbumNameInput(e.target.value);
                  setCurrentAlbumName(e.target.value);
                }}
                className="flex-1 bg-gray-950 border border-gray-700 focus:border-blue-500 rounded px-3 py-2 text-sm text-white focus:outline-none"
              />
              <button
                onClick={handleSaveCurrent}
                disabled={images.length === 0}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-semibold rounded cursor-pointer transition-colors flex items-center justify-center gap-1.5 shrink-0"
              >
                <span>💾</span>
                <span>Salva Album</span>
              </button>
              <button
                onClick={handleExport}
                disabled={images.length === 0}
                className="px-3 py-2 bg-gray-700 hover:bg-gray-600 disabled:opacity-50 text-white text-xs font-medium rounded cursor-pointer transition-colors flex items-center justify-center gap-1.5 shrink-0"
                title="Esporta questo album come file .triptych sul computer"
              >
                <span>💾 Esporta File...</span>
              </button>
            </div>
          </div>

          {/* Quick Actions Bar */}
          <div className="flex items-center justify-between gap-3 border-b border-gray-800 pb-3">
            <h3 className="text-sm font-bold text-gray-200">I Tuoi Album Salvati</h3>
            <div className="flex gap-2">
              <button
                onClick={handleImport}
                className="px-3 py-1.5 text-xs bg-gray-800 hover:bg-gray-700 border border-gray-700 text-gray-300 hover:text-white rounded cursor-pointer transition-colors flex items-center gap-1.5"
              >
                <span>📂</span>
                <span>Importa da File...</span>
              </button>
              <button
                onClick={handleNewAlbum}
                className="px-3 py-1.5 text-xs bg-green-700/80 hover:bg-green-600 text-white font-medium rounded cursor-pointer transition-colors flex items-center gap-1.5"
              >
                <span>➕</span>
                <span>Nuovo Album</span>
              </button>
            </div>
          </div>

          {/* Saved Albums List */}
          <div className="flex flex-col gap-2">
            {savedAlbums.length === 0 ? (
              <div className="text-center py-8 text-gray-500 text-sm">
                <p className="text-2xl mb-2">📭</p>
                <p>Nessun album salvato nella libreria.</p>
                <p className="text-xs text-gray-600 mt-1">
                  Inserisci le tue foto e clicca su "Salva Album" per ritrovarle sempre qui.
                </p>
              </div>
            ) : (
              savedAlbums.map((album) => {
                const isCurrent = currentAlbumId === album.id;
                const isEditing = editingAlbumId === album.id;

                return (
                  <div
                    key={album.id}
                    className={`flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-lg border transition-colors gap-3 ${
                      isCurrent
                        ? 'bg-blue-950/30 border-blue-600/50'
                        : 'bg-gray-800/40 border-gray-700/50 hover:bg-gray-800/70'
                    }`}
                  >
                    {/* Left: Info */}
                    <div className="flex flex-col gap-1 min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        {isEditing ? (
                          <div className="flex items-center gap-1 flex-1">
                            <input
                              type="text"
                              value={editingName}
                              onChange={(e) => setEditingName(e.target.value)}
                              className="bg-black border border-blue-500 px-2 py-1 rounded text-sm text-white w-full"
                              autoFocus
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleSaveRename(album.id);
                                if (e.key === 'Escape') setEditingAlbumId(null);
                              }}
                            />
                            <button
                              onClick={() => handleSaveRename(album.id)}
                              className="px-2 py-1 bg-green-600 text-xs rounded text-white cursor-pointer"
                            >
                              ✓
                            </button>
                            <button
                              onClick={() => setEditingAlbumId(null)}
                              className="px-2 py-1 bg-gray-700 text-xs rounded text-gray-300 cursor-pointer"
                            >
                              ✕
                            </button>
                          </div>
                        ) : (
                          <>
                            <span className="font-semibold text-sm text-white truncate">
                              {album.name}
                            </span>
                            {isCurrent && (
                              <span className="bg-blue-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded uppercase">
                                Aperto
                              </span>
                            )}
                          </>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-gray-400">
                        <span>📷 {album.images.length} foto</span>
                        <span>⏱ {album.settings?.interval ?? 5}s</span>
                        <span>
                          {album.settings?.mode === 'sequential'
                            ? '🔄 Continua'
                            : album.settings?.mode === 'shuffle'
                            ? '🔀 Shuffle'
                            : '🎲 Casuale'}
                        </span>
                        <span>📐 Margine: {album.settings?.panelGap ?? 0}px</span>
                        <span className="text-gray-500 text-[11px]">
                          Modificato: {formatDate(album.updatedAt)}
                        </span>
                      </div>
                    </div>

                    {/* Right: Actions */}
                    <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0">
                      <button
                        onClick={() => handleLoad(album)}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded cursor-pointer transition-colors flex items-center gap-1"
                        title="Carica questo album"
                      >
                        <span>▶</span>
                        <span>Carica</span>
                      </button>

                      <button
                        onClick={() => handleStartRename(album)}
                        className="p-1.5 bg-gray-700 hover:bg-gray-600 text-gray-300 hover:text-white text-xs rounded cursor-pointer transition-colors"
                        title="Rinomina album"
                      >
                        ✏️
                      </button>

                      <button
                        onClick={() => handleDelete(album.id, album.name)}
                        className="p-1.5 bg-gray-700 hover:bg-red-600 text-gray-300 hover:text-white text-xs rounded cursor-pointer transition-colors"
                        title="Elimina album"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-gray-800 bg-gray-800/40 flex items-center justify-between text-xs text-gray-400">
          <span>
            💡 I file <code>.triptych</code> contengono le foto, i collegamenti e le impostazioni.
          </span>
          <button
            onClick={() => setAlbumModalOpen(false)}
            className="px-4 py-1.5 bg-gray-700 hover:bg-gray-600 text-white rounded cursor-pointer transition-colors font-medium"
          >
            Chiudi
          </button>
        </div>
      </div>
    </div>
  );
}
