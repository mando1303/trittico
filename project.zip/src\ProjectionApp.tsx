import { useEffect, useState, useRef } from 'react';
import { Triptych } from './components/projection/Triptych';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { emit } from '@tauri-apps/api/event';

function ProjectionApp() {
  const params = new URLSearchParams(window.location.search);
  const role = (params.get('role') as 'single' | 'left' | 'right') || 'single';
  const isPreview = params.get('preview') === 'true';

  const [showControls, setShowControls] = useState(true);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Auto-hide floating top bar after 2.5s of no mouse movement
  const handleMouseMove = () => {
    setShowControls(true);
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    hideTimerRef.current = setTimeout(() => {
      setShowControls(false);
    }, 2500);
  };

  useEffect(() => {
    hideTimerRef.current = setTimeout(() => {
      setShowControls(false);
    }, 3000);
    return () => {
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        getCurrentWindow().close().catch(console.error);
      } else if (e.key === ' ' || e.code === 'Space') {
        e.preventDefault();
        emit('slideshow-control', { action: 'toggle-play' }).catch(console.error);
      } else if (e.key === 'ArrowRight' || e.key === 'n' || e.key === 'N') {
        e.preventDefault();
        emit('slideshow-control', { action: 'advance' }).catch(console.error);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        emit('slideshow-control', { action: 'volume-up' }).catch(console.error);
        handleMouseMove();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        emit('slideshow-control', { action: 'volume-down' }).catch(console.error);
        handleMouseMove();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleClose = () => {
    getCurrentWindow().close().catch(console.error);
  };

  const handleTogglePlay = () => {
    emit('slideshow-control', { action: 'toggle-play' }).catch(console.error);
  };

  const handleAdvance = () => {
    emit('slideshow-control', { action: 'advance' }).catch(console.error);
  };

  return (
    <div
      onMouseMove={handleMouseMove}
      onDoubleClick={handleClose}
      className={`projection-bg flex items-center justify-center relative overflow-hidden select-none ${
        showControls ? 'cursor-default' : 'cursor-none'
      }`}
    >
      <Triptych role={role} />

      {/* Floating discreet top bar that auto-hides for 100% clean presentation */}
      <div
        className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-black/85 backdrop-blur-md px-3.5 py-2 rounded-full border border-gray-700/70 shadow-2xl transition-all duration-300 ${
          showControls ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 -translate-y-4 pointer-events-none'
        }`}
      >
        <span className="text-xs font-bold text-gray-300 flex items-center gap-1.5 pl-1 pr-2 border-r border-gray-700">
          <span>🎬</span>
          <span>{isPreview ? 'Anteprima a Schermo Intero' : 'Proiezione'}</span>
        </span>

        <button
          onClick={handleTogglePlay}
          className="px-2.5 py-1 rounded-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold cursor-pointer transition-colors shadow flex items-center gap-1"
          title="Play / Pausa (Spazio)"
        >
          <span>▶ / ⏸</span>
          <span className="text-[10px] text-blue-200">Spazio</span>
        </button>

        <button
          onClick={handleAdvance}
          className="px-2.5 py-1 rounded-full bg-gray-800 hover:bg-gray-700 text-gray-200 hover:text-white text-xs font-medium border border-gray-600 cursor-pointer transition-colors flex items-center gap-1"
          title="Avanti (Freccia destra)"
        >
          <span>⏭</span>
          <span className="text-[10px] text-gray-400">Avanti</span>
        </button>

        {/* Volume controls */}
        <div className="flex items-center gap-1 pl-1 border-l border-gray-700">
          <button
            onClick={() => {
              emit('slideshow-control', { action: 'volume-down' }).catch(console.error);
              handleMouseMove();
            }}
            className="px-2 py-1 rounded-full bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white text-xs font-medium border border-gray-700 cursor-pointer transition-colors flex items-center gap-0.5"
            title="Abbassa Volume (Freccia Giù)"
          >
            <span>🔉</span>
            <span className="text-[10px] text-gray-400">-</span>
          </button>
          <button
            onClick={() => {
              emit('slideshow-control', { action: 'volume-up' }).catch(console.error);
              handleMouseMove();
            }}
            className="px-2 py-1 rounded-full bg-gray-800 hover:bg-gray-700 text-amber-300 hover:text-amber-200 text-xs font-semibold border border-gray-700 cursor-pointer transition-colors flex items-center gap-0.5"
            title="Alza Volume & Boost Amplificato (Freccia Su)"
          >
            <span>🔊</span>
            <span className="text-[10px] text-amber-400">+</span>
          </button>
        </div>

        <button
          onClick={handleClose}
          className="ml-1 px-3 py-1 rounded-full bg-gray-700 hover:bg-gray-600 text-white text-xs font-bold border border-gray-600 cursor-pointer transition-colors shadow flex items-center gap-1"
          title="Chiudi schermata a tutto schermo (Esc o Doppio Clic)"
        >
          <span>✕ Chiudi</span>
          <kbd className="text-[10px] bg-gray-800 px-1 py-0.5 rounded text-gray-200 border border-gray-600">Esc</kbd>
        </button>
      </div>
    </div>
  );
}

export default ProjectionApp;
