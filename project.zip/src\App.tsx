import { useState, useEffect, useCallback, useRef } from 'react';
import { emit, listen } from '@tauri-apps/api/event';
import { WebviewWindow } from '@tauri-apps/api/webviewWindow';
import { currentMonitor } from '@tauri-apps/api/window';
import { useSlideshow } from './hooks/useSlideshow';
import { useAudioPlayer } from './hooks/useAudioPlayer';
import { useStore } from './stores/useStore';
import ImportZone from './components/control/ImportZone';
import Gallery from './components/control/Gallery';
import AudioList from './components/control/AudioList';
import AlbumModal from './components/control/AlbumModal';
import { openCleanFullscreenPreview } from './utils/previewWindow';

function App() {
  useSlideshow();
  useAudioPlayer();
  const currentAlbumId = useStore((s) => s.currentAlbumId);
  const currentAlbumName = useStore((s) => s.currentAlbumName);
  const setAlbumModalOpen = useStore((s) => s.setAlbumModalOpen);
  const saveAlbum = useStore((s) => s.saveAlbum);
  const images = useStore((s) => s.images);
  const audioTracks = useStore((s) => s.audioTracks);
  const audioSettings = useStore((s) => s.audioSettings);
  const settings = useStore((s) => s.settings);
  const activeTab = useStore((s) => s.activeTab);
  const setActiveTab = useStore((s) => s.setActiveTab);
  const newAlbum = useStore((s) => s.newAlbum);
  const isPlaying = useStore((s) => s.isPlaying);
  const togglePlay = useStore((s) => s.togglePlay);
  const currentAudioIndex = useStore((s) => s.currentAudioIndex);
  const triptych = useStore((s) => s.triptych);
  const isProjectionOpen = useStore((s) => s.isProjectionOpen);
  const isFullPreviewOpen = useStore((s) => s.isFullPreviewOpen);

  const [isControlsWindowOpen, setControlsWindowOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimeoutRef = useRef<any>(null);

  const showToast = useCallback((msg: string) => {
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    setToastMessage(msg);
    toastTimeoutRef.current = setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  }, []);

  // Broadcast state snapshot to detached controls window
  const broadcastStoreState = useCallback(() => {
    try {
      emit('store-sync', {
        images: (images || []).map((img) => ({
          id: img.id,
          name: img.name,
          assetUrl: img.assetUrl,
          path: img.path,
          targetPanel: img.targetPanel,
          pairedImageId: img.pairedImageId,
          customDuration: img.customDuration,
        })),
        imagesCount: (images || []).length,
        audioTracks: (audioTracks || []).map((t) => ({ id: t.id, name: t.name, assetUrl: t.assetUrl, path: t.path })),
        audioSettings,
        settings,
        isPlaying,
        currentAudioIndex,
        triptych,
        isProjectionOpen,
        isFullPreviewOpen,
        currentAlbumName,
      }).catch((e) => console.warn('store-sync emit error:', e));
    } catch (err) {
      console.warn('broadcastStoreState error:', err);
    }
  }, [images, audioTracks, audioSettings, settings, isPlaying, currentAudioIndex, triptych, isProjectionOpen, isFullPreviewOpen, currentAlbumName]);

  const broadcastStoreStateRef = useRef(broadcastStoreState);
  useEffect(() => {
    broadcastStoreStateRef.current = broadcastStoreState;
  }, [broadcastStoreState]);

  // Synchronize on every state change
  useEffect(() => {
    broadcastStoreState();
  }, [broadcastStoreState]);

  // Listen for sync requests and action dispatches from detached controls window (never re-bind to avoid dropping events)
  useEffect(() => {
    const unlistenReq = listen('request-store-sync', () => {
      broadcastStoreStateRef.current();
    });

    const unlistenDispatch = listen<{ action: string; payload?: any }>('store-dispatch', (event) => {
      const { action, payload } = event.payload;
      const store = useStore.getState();
      if (action === 'togglePlay') store.togglePlay();
      else if (action === 'setPlaying') store.setPlaying(payload);
      else if (action === 'updateSettings') store.updateSettings(payload);
      else if (action === 'updateAudioSettings') store.updateAudioSettings(payload);
      else if (action === 'advanceSlideshow') store.advanceSlideshow();
      else if (action === 'resetSlideshow') store.resetSlideshow();
      else if (action === 'initSlideshow') store.initSlideshow();
      else if (action === 'nextAudioTrack') store.nextAudioTrack();
      else if (action === 'previousAudioTrack') store.previousAudioTrack();
      else if (action === 'setProjectionOpen') store.setProjectionOpen(payload);
      else if (action === 'clearImages') store.clearImages();
      else if (action === 'setImageCustomDuration') store.setImageCustomDuration(payload.id, payload.duration);
      else if (action === 'setImagePanelPosition') store.setImagePanelPosition(payload.id, payload.position);
      else if (action === 'saveAlbum') {
        store.saveAlbum().then(() => {
          showToast(`✅ Modifiche all'album "${store.currentAlbumName || 'Album'}" salvate!`);
        });
      }
    });

    return () => {
      unlistenReq.then((fn) => fn());
      unlistenDispatch.then((fn) => fn());
    };
  }, []);

  // Open or focus independent native controls window
  const handleOpenDetachedControls = async () => {
    try {
      const existing = await WebviewWindow.getByLabel('controls');
      if (existing) {
        await existing.show();
        await existing.setFocus();
        setControlsWindowOpen(true);
        return;
      }

      let targetWidth = 420;
      let targetHeight = 560;

      try {
        const monitor = await currentMonitor();
        if (monitor) {
          const logicalHeight = monitor.size.height / monitor.scaleFactor;
          // Ensure window height never exceeds the screen or hides beneath the Windows taskbar
          targetHeight = Math.min(580, Math.max(380, Math.round(logicalHeight - 140)));
        }
      } catch (err) {
        console.warn('Could not query current monitor size:', err);
      }

      const win = new WebviewWindow('controls', {
        url: '/?window=controls',
        title: 'Triptych - Controlli & Proiezione',
        width: targetWidth,
        height: targetHeight,
        minWidth: 320,
        minHeight: 350,
        resizable: true,
        decorations: true,
        alwaysOnTop: false,
      });

      win.once('tauri://created', () => {
        setControlsWindowOpen(true);
        setTimeout(() => broadcastStoreState(), 100);
      });

      win.once('tauri://destroyed', () => {
        setControlsWindowOpen(false);
      });

      win.once('tauri://error', (err) => {
        console.error('Error creating detached controls window:', err);
      });
    } catch (e) {
      console.error(e);
    }
  };

  // Keyboard shortcuts: 'C' (controls), 'Space' (play/pause), 'F' / 'F11' (fullscreen preview)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return;
      }
      if (e.key === 'c' || e.key === 'C') {
        e.preventDefault();
        handleOpenDetachedControls();
      } else if (e.key === ' ' || e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'f' || e.key === 'F' || e.key === 'F11') {
        e.preventDefault();
        openCleanFullscreenPreview();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [togglePlay]);

  const handleQuickSave = async () => {
    await saveAlbum();
    showToast(`✅ Modifiche all'album "${currentAlbumName || 'Album'}" salvate con successo!`);
  };

  return (
    <div className="h-screen w-screen bg-[#0f0f0f] text-white p-3 flex flex-col gap-2.5 overflow-hidden box-border">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-emerald-600/95 text-white px-5 py-2.5 rounded-lg shadow-2xl border border-emerald-400 font-medium text-sm flex items-center gap-2 backdrop-blur pointer-events-none transition-all">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <header className="shrink-0 flex flex-wrap items-center justify-between border-b border-gray-700 pb-2.5 gap-2">
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-bold tracking-wide">🎬 Triptych Slideshow</h1>
          <div className="h-5 w-[1px] bg-gray-700 hidden sm:block" />
          <button
            onClick={() => setAlbumModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-gray-800/80 hover:bg-gray-700 border border-gray-700 rounded text-xs text-gray-200 hover:text-white cursor-pointer transition-colors"
            title="Clicca per aprire la gestione degli Album"
          >
            <span className="text-blue-400">📁 Album:</span>
            <span className="font-semibold">{currentAlbumName || 'Nuovo Album'}</span>
            <span className="text-[10px] text-gray-400 ml-1">▾</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {/* Quick Play / Pause Button in Header */}
          <button
            onClick={() => togglePlay()}
            disabled={images.length === 0 && audioTracks.length === 0}
            className={`px-3 py-1.5 rounded text-xs font-bold cursor-pointer transition-all flex items-center gap-1.5 shadow ${
              isPlaying
                ? 'bg-amber-600 hover:bg-amber-500 text-white ring-2 ring-amber-400/50'
                : 'bg-gray-700 hover:bg-gray-600 text-white border border-gray-600 disabled:opacity-40 disabled:cursor-not-allowed'
            }`}
            title="Avvia o metti in pausa lo slideshow (o premi Spazio)"
          >
            <span>{isPlaying ? '⏸ In Pausa' : '▶ Play Slideshow'}</span>
          </button>

          {/* Clean Fullscreen Preview Button */}
          <button
            onClick={() => openCleanFullscreenPreview()}
            className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-200 hover:text-white border border-gray-700 text-xs font-semibold rounded cursor-pointer transition-colors flex items-center gap-1.5 shadow"
            title="Apri l'anteprima cinematografica a tutto schermo (tasto F o F11)"
          >
            <span>🎬</span>
            <span>Anteprima Schermo Intero</span>
            <kbd className="text-[10px] bg-gray-900/80 px-1 py-0.5 rounded text-gray-400 ml-0.5">F</kbd>
          </button>

          {/* Detached Controls Window Trigger Button */}
          <button
            onClick={handleOpenDetachedControls}
            className={`px-3 py-1.5 rounded text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 shadow ${
              isControlsWindowOpen
                ? 'bg-indigo-600 hover:bg-indigo-500 text-white ring-2 ring-indigo-400/50'
                : 'bg-gray-800 hover:bg-gray-700 text-gray-200 hover:text-white border border-gray-700'
            }`}
            title="Apri la finestra indipendente dei controlli per spostarla liberamente (tasto C)"
          >
            <span>🎛️</span>
            <span>{isControlsWindowOpen ? 'Finestra Controlli (Aperta)' : 'Stacca Finestra Controlli'}</span>
            {isPlaying && (
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse ml-0.5" title="In riproduzione" />
            )}
            {isProjectionOpen && (
              <span className="w-2 h-2 rounded-full bg-indigo-400 ml-0.5" title="Proiezione attiva" />
            )}
            <kbd className="text-[10px] bg-gray-900/80 px-1 py-0.5 rounded text-gray-300 ml-0.5">C</kbd>
          </button>

          <button
            onClick={handleQuickSave}
            disabled={images.length === 0 && audioTracks.length === 0}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-xs font-semibold rounded cursor-pointer transition-colors flex items-center gap-1.5 shadow"
            title="Salva l'album corrente o le modifiche apportate (foto, ordine, musica, impostazioni)"
          >
            <span>💾</span>
            <span>{currentAlbumId ? 'Salva Modifiche' : 'Salva Album'}</span>
          </button>

          <button
            onClick={() => setAlbumModalOpen(true)}
            className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-200 hover:text-white border border-gray-700 text-xs font-medium rounded cursor-pointer transition-colors flex items-center gap-1.5"
            title="Visualizza tutti gli album salvati ed esporta/importa su file"
          >
            <span>📂</span>
            <span>I Miei Album</span>
          </button>

          <button
            onClick={() => {
              if (images.length > 0 || audioTracks.length > 0) {
                if (!window.confirm('Vuoi creare un nuovo album? La galleria e le tracce audio verranno svuotate.')) return;
              }
              newAlbum();
            }}
            className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white border border-gray-700 text-xs font-medium rounded cursor-pointer transition-colors flex items-center gap-1"
            title="Inizia un nuovo album da zero"
          >
            <span>➕ Nuovo</span>
          </button>
        </div>
      </header>

      {/* Main workspace: 100% Full Width for Maximum Thumbnail Space */}
      <div className="flex-1 flex flex-col gap-2 min-w-0 min-h-0 overflow-hidden">
        {/* Top bar with Tabs on Left and Collapsible Import on Right */}
        <div className="shrink-0 flex flex-wrap items-center justify-between gap-2 pb-0.5">
          {/* Tab Selector */}
          <div className="flex items-center gap-1 bg-gray-900 p-1 rounded-lg border border-gray-800">
            <button
              onClick={() => setActiveTab('images')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 ${
                activeTab === 'images'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <span>📷 Immagini</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                activeTab === 'images' ? 'bg-blue-800 text-white' : 'bg-gray-800 text-gray-400'
              }`}>
                {images.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('audio')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 ${
                activeTab === 'audio'
                  ? 'bg-emerald-600 text-white shadow'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <span>🎵 Musica & Audio</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                activeTab === 'audio' ? 'bg-emerald-800 text-white' : 'bg-gray-800 text-gray-400'
              }`}>
                {audioTracks.length}
              </span>
            </button>
          </div>

          <ImportZone />
        </div>

        {activeTab === 'images' ? <Gallery /> : <AudioList />}
      </div>

      {/* Floating button in bottom right to open/focus detached controls */}
      <button
        onClick={handleOpenDetachedControls}
        className="fixed bottom-4 right-4 z-30 px-3.5 py-2.5 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-2xl backdrop-blur flex items-center gap-2 border border-indigo-400/50 cursor-pointer transition-all hover:scale-105"
        title="Stacca o porta in primo piano la finestra dei controlli (tasto C)"
      >
        <span>🎛️</span>
        <span>{isControlsWindowOpen ? 'Mostra Controlli' : 'Stacca Controlli'}</span>
        <kbd className="text-[10px] bg-indigo-900/90 px-1.5 py-0.5 rounded text-white border border-indigo-500/50">C</kbd>
      </button>

      {/* Album Management Modal */}
      <AlbumModal />
    </div>
  );
}

export default App;
