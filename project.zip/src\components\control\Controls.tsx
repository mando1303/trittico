import { useStore } from '../../stores/useStore';
import { WebviewWindow } from '@tauri-apps/api/webviewWindow';
import { availableMonitors } from '@tauri-apps/api/window';
import { emit } from '@tauri-apps/api/event';
import { useEffect, useState } from 'react';
import { openCleanFullscreenPreview } from '../../utils/previewWindow';

type MonitorInfo = {
  name: string | null;
  size: { width: number; height: number };
  position: { x: number; y: number };
};

export default function Controls() {
  const isPlaying = useStore((s) => s.isPlaying);
  const setPlaying = useStore((s) => s.setPlaying);
  const togglePlay = useStore((s) => s.togglePlay);
  const images = useStore((s) => s.images);
  const resetSlideshow = useStore((s) => s.resetSlideshow);
  const triptych = useStore((s) => s.triptych);
  const isProjectionOpen = useStore((s) => s.isProjectionOpen);
  const setProjectionOpen = useStore((s) => s.setProjectionOpen);
  const settings = useStore((s) => s.settings);
  const updateSettings = useStore((s) => s.updateSettings);
  const audioTracks = useStore((s) => s.audioTracks);
  const audioSettings = useStore((s) => s.audioSettings);
  const updateAudioSettings = useStore((s) => s.updateAudioSettings);
  const currentAlbumName = useStore((s) => s.currentAlbumName);
  const saveAlbum = useStore((s) => s.saveAlbum);

  const [monitors, setMonitors] = useState<MonitorInfo[]>([]);
  const [selectedMonitor, setSelectedMonitor] = useState<number>(0);
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);

  // List available monitors
  useEffect(() => {
    async function loadMonitors() {
      try {
        const available = await availableMonitors();
        const monitorInfos: MonitorInfo[] = available.map((m: any) => ({
          name: m.name,
          size: { width: m.size.width, height: m.size.height },
          position: { x: m.position.x, y: m.position.y },
        }));
        setMonitors(monitorInfos);
        // Default to second monitor if available
        if (monitorInfos.length > 1) {
          setSelectedMonitor(1);
        }
      } catch (e) {
        console.error('Error loading monitors:', e);
      }
    }
    loadMonitors();
  }, []);

  const handleCloseAllProjections = async () => {
    try {
      const pSingle = await WebviewWindow.getByLabel('projection');
      if (pSingle) await pSingle.close();
    } catch (e) {
      console.warn('Error closing single projection:', e);
    }
    try {
      const pLeft = await WebviewWindow.getByLabel('projection_left');
      if (pLeft) await pLeft.close();
    } catch (e) {
      console.warn('Error closing left projection:', e);
    }
    try {
      const pRight = await WebviewWindow.getByLabel('projection_right');
      if (pRight) await pRight.close();
    } catch (e) {
      console.warn('Error closing right projection:', e);
    }
    setProjectionOpen(false);
  };

  const handleOpenProjection = async () => {
    if (isProjectionOpen) {
      await handleCloseAllProjections();
      return;
    }

    if (monitors.length === 0) return;

    const isDual = settings.projectionMode === 'dual';

    if (!isDual) {
      // Single projector mode
      const monitor = monitors[selectedMonitor] || monitors[0];
      if (!monitor) return;

      try {
        const projectionWindow = new WebviewWindow('projection', {
          url: '/?window=projection&role=single',
          title: 'Proiezione Triptych',
          x: monitor.position.x,
          y: monitor.position.y,
          width: monitor.size.width,
          height: monitor.size.height,
          fullscreen: true,
          decorations: false,
          alwaysOnTop: true,
          skipTaskbar: true,
        });

        projectionWindow.once('tauri://created', () => {
          setProjectionOpen(true);
          emit('request-triptych-update', {}).catch((e) => console.warn(e));
        });

        projectionWindow.once('tauri://error', (e) => {
          console.error('Projection window error:', e);
        });

        projectionWindow.once('tauri://destroyed', () => {
          setProjectionOpen(false);
          setPlaying(false);
        });
      } catch (e) {
        console.error('Error creating single projection window:', e);
      }
    } else {
      // Dual projector mode (7m panoramic)
      const leftIdx = Math.min(settings.leftMonitorIndex ?? 0, monitors.length - 1);
      const rightIdx = Math.min(settings.rightMonitorIndex ?? (monitors.length > 1 ? 1 : 0), monitors.length - 1);
      const leftMon = monitors[leftIdx] || monitors[0];
      const rightMon = monitors[rightIdx] || monitors[0];

      try {
        // Window 1: Left projector (left half + overlap)
        const leftWindow = new WebviewWindow('projection_left', {
          url: '/?window=projection&role=left',
          title: 'Proiezione - Proiettore Sinistro',
          x: leftMon.position.x,
          y: leftMon.position.y,
          width: leftMon.size.width,
          height: leftMon.size.height,
          fullscreen: true,
          decorations: false,
          alwaysOnTop: true,
          skipTaskbar: true,
        });

        // Window 2: Right projector (right half + overlap)
        const rightWindow = new WebviewWindow('projection_right', {
          url: '/?window=projection&role=right',
          title: 'Proiezione - Proiettore Destro',
          x: rightMon.position.x,
          y: rightMon.position.y,
          width: rightMon.size.width,
          height: rightMon.size.height,
          fullscreen: true,
          decorations: false,
          alwaysOnTop: true,
          skipTaskbar: true,
        });

        let createdCount = 0;
        const onCreated = () => {
          createdCount++;
          if (createdCount >= 1) {
            setProjectionOpen(true);
            emit('request-triptych-update', {}).catch((e) => console.warn(e));
          }
        };

        leftWindow.once('tauri://created', onCreated);
        rightWindow.once('tauri://created', onCreated);

        leftWindow.once('tauri://destroyed', () => {
          handleCloseAllProjections();
          setPlaying(false);
        });
        rightWindow.once('tauri://destroyed', () => {
          handleCloseAllProjections();
          setPlaying(false);
        });

        leftWindow.once('tauri://error', (e) => console.error('Left projection error:', e));
        rightWindow.once('tauri://error', (e) => console.error('Right projection error:', e));
      } catch (e) {
        console.error('Error creating dual projection windows:', e);
      }
    }
  };

  const handlePlay = () => {
    togglePlay();
  };

  const handleSaveAlbum = async () => {
    try {
      await saveAlbum();
      emit('store-dispatch', { action: 'saveAlbum' });
      setSaveFeedback('✅ Modifiche salvate con successo!');
      setTimeout(() => setSaveFeedback(null), 3000);
    } catch (e) {
      console.error(e);
      setSaveFeedback('❌ Errore durante il salvataggio');
      setTimeout(() => setSaveFeedback(null), 3000);
    }
  };

  const handleOpenRemoteController = async () => {
    try {
      const existing = await WebviewWindow.getByLabel('controller');
      if (existing) {
        await existing.show();
        await existing.setFocus();
        return;
      }
      const win = new WebviewWindow('controller', {
        url: '/?window=controller',
        title: 'Telecomando Triptych',
        width: 380,
        height: 380,
        resizable: false,
        alwaysOnTop: true,
        decorations: true,
      });
      win.once('tauri://error', (err) => {
        console.error('Error opening controller window:', err);
      });
    } catch (e) {
      console.error(e);
    }
  };

  const currentAudioIndex = useStore((s) => s.currentAudioIndex);
  const nextAudioTrack = useStore((s) => s.nextAudioTrack);
  const previousAudioTrack = useStore((s) => s.previousAudioTrack);

  const handleStop = () => {
    resetSlideshow();
  };

  const playImages = settings.playImages ?? true;
  const audioEnabled = audioSettings.enabled;

  const isImageContinua = settings.continuous ?? true;
  const isImageCasuale = settings.mode === 'shuffle';

  const isAudioContinua = audioSettings.continuous ?? true;
  const isAudioCasuale = audioSettings.mode === 'shuffle';

  const canPlayImages = playImages && images.length >= 1;
  const canPlayAudio = audioEnabled && audioTracks.length > 0;
  const canPlay = canPlayImages || canPlayAudio;
  const currentTrack = audioTracks[currentAudioIndex] || null;

  return (
    <div className="bg-gray-800/50 rounded-lg p-4 flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-gray-300 uppercase tracking-wider">Controlli</h2>
        <button
          onClick={handleOpenRemoteController}
          className="text-xs text-blue-400 hover:text-blue-300 font-medium cursor-pointer transition-colors flex items-center gap-1"
          title="Apri il controller in una finestra desktop separata"
        >
          <span>🎮</span>
          <span>Telecomando</span>
        </button>
      </div>

      {/* Save Album Modifications Quick Button */}
      <button
        onClick={handleSaveAlbum}
        className="w-full py-2 px-3 rounded-lg text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white transition-all shadow cursor-pointer flex items-center justify-center gap-2 border border-blue-400/40"
        title="Salva tutte le modifiche apportate a questo album (foto, musica e impostazioni)"
      >
        <span>💾</span>
        <span>Salva Modifiche Album {currentAlbumName ? `("${currentAlbumName}")` : ''}</span>
      </button>
      {saveFeedback && (
        <div className="text-[11px] text-center text-emerald-300 font-bold bg-emerald-950/80 p-1.5 rounded border border-emerald-700/60 animate-fade-in">
          {saveFeedback}
        </div>
      )}

      {/* Clean Fullscreen Preview Button */}
      <button
        onClick={openCleanFullscreenPreview}
        className="w-full py-2.5 rounded-lg text-sm font-bold bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white transition-all shadow cursor-pointer flex items-center justify-center gap-2"
        title="Apri anteprima pulita a schermo intero senza bordi (Esc per chiudere)"
      >
        <span>🎬 Anteprima Risultato Finale</span>
        <span className="text-[11px] font-normal bg-black/30 px-1.5 py-0.5 rounded">Schermo Intero</span>
      </button>

      {/* Scelta Modalità di Riproduzione (Spunte dedicate per Immagini e Audio) */}
      <div className="bg-gray-900/95 p-3 rounded-lg border border-gray-750 flex flex-col gap-2.5 shadow-sm">
        {/* Intestazione e stato corrente */}
        <div className="flex items-center justify-between pb-1.5 border-b border-gray-800">
          <span className="font-semibold text-gray-300 uppercase tracking-wider text-[10px]">
            Modalità di Riproduzione
          </span>
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
            playImages && audioEnabled
              ? 'bg-purple-900/50 text-purple-300 border border-purple-700/60'
              : playImages
              ? 'bg-blue-900/50 text-blue-300 border border-blue-700/60'
              : audioEnabled
              ? 'bg-emerald-900/50 text-emerald-300 border border-emerald-700/60'
              : 'bg-gray-800 text-gray-400'
          }`}>
            {playImages && audioEnabled
              ? `⚡ Simultanea (Foto + Musica)`
              : playImages
              ? `📷 Solo Immagini`
              : audioEnabled
              ? `🎵 Solo Musica`
              : '⏸ Nessuno attivo'}
          </span>
        </div>

        {/* 📷 IMMAGINI */}
        <div className={`p-2.5 rounded-lg border transition-all ${
          playImages 
            ? 'bg-blue-950/25 border-blue-800/70 shadow-sm' 
            : 'bg-gray-950/50 border-gray-800/80 opacity-60'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={playImages}
                onChange={(e) => updateSettings({ playImages: e.target.checked })}
                className="rounded accent-blue-500 cursor-pointer w-4 h-4"
              />
              <span className="text-xs font-bold text-gray-200 flex items-center gap-1.5">
                <span>📷</span>
                <span>Riproduci Immagini</span>
              </span>
            </label>
            <span className="text-[10px] text-gray-400">
              {images.length} foto
            </span>
          </div>

          {/* Indicatore fisso Rotazione Sinistra -> Destra */}
          <div className="flex items-center justify-between bg-blue-900/25 border border-blue-800/40 rounded-lg px-2.5 py-1.5 text-xs text-blue-200">
            <span className="flex items-center gap-1.5 font-medium">
              <span>➡️</span>
              <span>Rotazione: Da Sinistra a Destra</span>
            </span>
            <span className="text-[10px] text-blue-300/80 font-normal">Fissa (1 ➔ 2 ➔ 3)</span>
          </div>

          {/* Spunte Continua e Casuale */}
          <div className="grid grid-cols-2 gap-2 mt-2">
            <label className={`flex items-start gap-2 p-2 rounded-lg cursor-pointer border select-none transition-all ${
              isImageContinua
                ? 'bg-blue-600/30 border-blue-500 text-white font-medium shadow-sm'
                : 'bg-gray-900/80 border-gray-800 text-gray-400 hover:bg-gray-850 hover:text-white'
            }`}>
              <input
                type="checkbox"
                checked={isImageContinua}
                onChange={(e) => updateSettings({ continuous: e.target.checked })}
                className="mt-0.5 rounded accent-blue-500 cursor-pointer w-4 h-4"
              />
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-semibold leading-tight">🔄 Continua</span>
                <span className="text-[9px] text-gray-400 font-normal mt-0.5">Ciclo continuo / Loop</span>
              </div>
            </label>

            <label className={`flex items-start gap-2 p-2 rounded-lg cursor-pointer border select-none transition-all ${
              isImageCasuale
                ? 'bg-blue-600/30 border-blue-500 text-white font-medium shadow-sm'
                : 'bg-gray-900/80 border-gray-800 text-gray-400 hover:bg-gray-850 hover:text-white'
            }`}>
              <input
                type="checkbox"
                checked={isImageCasuale}
                onChange={(e) => updateSettings({ mode: e.target.checked ? 'shuffle' : 'sequential' })}
                className="mt-0.5 rounded accent-blue-500 cursor-pointer w-4 h-4"
              />
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-semibold leading-tight">🔀 Casuale</span>
                <span className="text-[9px] text-gray-400 font-normal mt-0.5">Ricomincia sempre</span>
              </div>
            </label>
          </div>

          <div className="mt-1 text-[10px] text-center text-blue-300/90 font-medium">
            {!playImages
              ? 'Immagini disattivate'
              : isImageCasuale && isImageContinua
              ? '✨ Casuale e Continua insieme (loop continuo rimescolato)'
              : isImageCasuale
              ? '🔀 Riproduzione Casuale (ricomincia sempre senza fermarsi)'
              : isImageContinua
              ? '🔄 Riproduzione Continua da Sinistra a Destra (1 ➔ 2 ➔ 3... in loop)'
              : '➡️ Riproduzione Ordinata (singola passata, si ferma alla fine)'}
          </div>
        </div>

        {/* 🎵 AUDIO / MUSICA */}
        <div className={`p-2.5 rounded-lg border transition-all ${
          audioEnabled 
            ? 'bg-emerald-950/25 border-emerald-800/70 shadow-sm' 
            : 'bg-gray-950/50 border-gray-800/80 opacity-60'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={audioEnabled}
                onChange={(e) => updateAudioSettings({ enabled: e.target.checked })}
                className="rounded accent-emerald-500 cursor-pointer w-4 h-4"
              />
              <span className="text-xs font-bold text-gray-200 flex items-center gap-1.5">
                <span>🎵</span>
                <span>Riproduci Audio</span>
              </span>
            </label>
            <span className="text-[10px] text-gray-400">
              {audioTracks.length} tracce
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <label className={`flex items-start gap-2 p-2 rounded-lg cursor-pointer border select-none transition-all ${
              isAudioContinua
                ? 'bg-emerald-600/30 border-emerald-500 text-white font-medium shadow-sm'
                : 'bg-gray-900/80 border-gray-800 text-gray-400 hover:bg-gray-850 hover:text-white'
            }`}>
              <input
                type="checkbox"
                checked={isAudioContinua}
                onChange={(e) => updateAudioSettings({ continuous: e.target.checked })}
                className="mt-0.5 rounded accent-emerald-500 cursor-pointer w-4 h-4"
              />
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-semibold leading-tight">🔄 Continua</span>
                <span className="text-[9px] text-gray-400 font-normal mt-0.5">Ciclo continuo / Loop</span>
              </div>
            </label>

            <label className={`flex items-start gap-2 p-2 rounded-lg cursor-pointer border select-none transition-all ${
              isAudioCasuale
                ? 'bg-emerald-600/30 border-emerald-500 text-white font-medium shadow-sm'
                : 'bg-gray-900/80 border-gray-800 text-gray-400 hover:bg-gray-850 hover:text-white'
            }`}>
              <input
                type="checkbox"
                checked={isAudioCasuale}
                onChange={(e) => updateAudioSettings({ mode: e.target.checked ? 'shuffle' : 'sequential' })}
                className="mt-0.5 rounded accent-emerald-500 cursor-pointer w-4 h-4"
              />
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-semibold leading-tight">🔀 Casuale</span>
                <span className="text-[9px] text-gray-400 font-normal mt-0.5">Shuffle / Rimescola</span>
              </div>
            </label>
          </div>

          <div className="mt-1.5 text-[10px] text-center text-emerald-300/90 font-medium">
            {!audioEnabled
              ? 'Audio disattivato'
              : isAudioContinua && isAudioCasuale
              ? '✨ Casuale e Continua contemporaneamente'
              : isAudioContinua
              ? '🔄 Continua in sequenza di playlist'
              : isAudioCasuale
              ? '🔀 Casuale (singola passata)'
              : '⏸ Fermo (attiva Continua o Casuale)'}
          </div>

          {/* Mini audio bar if audio enabled and tracks present */}
          {audioEnabled && audioTracks.length > 0 && (
            <div className="mt-2.5 pt-2 border-t border-gray-800/80 flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-gray-300 truncate max-w-[170px]" title={currentTrack?.name || ''}>
                  🎶 <span className="text-white font-medium">{currentTrack?.name || 'In attesa'}</span>
                </span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => previousAudioTrack()}
                    className="p-1 bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white rounded cursor-pointer transition-colors"
                    title="Brano precedente"
                  >
                    ⏮
                  </button>
                  <button
                    onClick={() => nextAudioTrack()}
                    className="p-1 bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white rounded cursor-pointer transition-colors"
                    title="Brano successivo"
                  >
                    ⏭
                  </button>
                </div>
              </div>
              <div className="flex flex-col gap-1.5 pt-1 border-t border-gray-800/80">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-gray-400 flex items-center gap-1.5">
                    <span>🔊 Volume:</span>
                    {audioSettings.volume > 1.0 && (
                      <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                        ⚡ Boost +{Math.round((audioSettings.volume - 1.0) * 100)}%
                      </span>
                    )}
                  </span>
                  <span className={`font-bold ${audioSettings.volume > 1.0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {Math.round(audioSettings.volume * 100)}%
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] text-gray-500">0%</span>
                  <input
                    type="range"
                    min={0}
                    max={2.5}
                    step={0.05}
                    value={audioSettings.volume}
                    onChange={(e) => updateAudioSettings({ volume: Number(e.target.value) })}
                    className={`flex-1 h-1.5 bg-gray-700 rounded cursor-pointer ${
                      audioSettings.volume > 1.0 ? 'accent-amber-500' : 'accent-emerald-500'
                    }`}
                    title="Volume audio (fino a 250% con amplificazione per registrazioni e proiettore)"
                  />
                  <span className="text-[10px] text-amber-500 font-semibold">250%</span>
                </div>
                {/* Pulsanti rapidi volume & boost */}
                <div className="grid grid-cols-4 gap-1 text-[9px]">
                  <button
                    type="button"
                    onClick={() => updateAudioSettings({ volume: 0.5 })}
                    className={`py-0.5 rounded cursor-pointer transition-colors text-center ${
                      Math.abs(audioSettings.volume - 0.5) < 0.01
                        ? 'bg-blue-600 text-white font-bold'
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white'
                    }`}
                  >
                    50%
                  </button>
                  <button
                    type="button"
                    onClick={() => updateAudioSettings({ volume: 1.0 })}
                    className={`py-0.5 rounded cursor-pointer transition-colors text-center ${
                      Math.abs(audioSettings.volume - 1.0) < 0.01
                        ? 'bg-emerald-600 text-white font-bold'
                        : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white'
                    }`}
                    title="Volume Standard (100%)"
                  >
                    100%
                  </button>
                  <button
                    type="button"
                    onClick={() => updateAudioSettings({ volume: 1.5 })}
                    className={`py-0.5 rounded cursor-pointer transition-colors text-center ${
                      Math.abs(audioSettings.volume - 1.5) < 0.01
                        ? 'bg-amber-600 text-white font-bold'
                        : 'bg-gray-800 text-amber-300 hover:bg-gray-700 hover:text-white'
                    }`}
                    title="Amplificazione audio (+50%)"
                  >
                    ⚡ 150%
                  </button>
                  <button
                    type="button"
                    onClick={() => updateAudioSettings({ volume: 2.0 })}
                    className={`py-0.5 rounded cursor-pointer transition-colors text-center ${
                      Math.abs(audioSettings.volume - 2.0) < 0.01
                        ? 'bg-orange-600 text-white font-bold'
                        : 'bg-gray-800 text-orange-300 hover:bg-gray-700 hover:text-white'
                    }`}
                    title="Doppio Volume (+100% Boost)"
                  >
                    ⚡ 200%
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Playback controls */}
      <div className="flex gap-2">
        <button
          onClick={handlePlay}
          disabled={!canPlay}
          className={`flex-1 py-2.5 rounded text-lg font-medium transition-colors cursor-pointer ${
            isPlaying
              ? 'bg-yellow-600 hover:bg-yellow-700'
              : 'bg-gray-700 hover:bg-gray-600 border border-gray-600'
          } text-white disabled:opacity-40 disabled:cursor-not-allowed shadow`}
        >
          {isPlaying ? '⏸ Pausa' : '▶ Play'}
        </button>
        <button
          onClick={handleStop}
          disabled={!isPlaying && !triptych.panels[0]}
          className="px-4 py-2.5 rounded text-lg bg-gray-600 hover:bg-gray-700 text-white 
                     transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          title="Stop e reset slideshow"
        >
          ⏹
        </button>
      </div>

      {!canPlay && (
        <p className="text-xs text-yellow-400/90 text-center bg-yellow-950/40 p-2 rounded border border-yellow-850">
          {!playImages && !audioEnabled
            ? 'Attiva almeno una spunta (Continua o Casuale per Immagini o Audio) per avviare.'
            : playImages && images.length < 1 && (!audioEnabled || audioTracks.length === 0)
            ? 'Carica almeno una immagine per avviare la riproduzione immagini.'
            : audioEnabled && audioTracks.length === 0 && (!playImages || images.length < 1)
            ? 'Carica almeno 1 brano audio per avviare la musica.'
            : 'Seleziona le opzioni per avviare la riproduzione.'}
        </p>
      )}

      {/* Divider */}
      <div className="border-t border-gray-700/60 pt-2.5 flex flex-col gap-2.5">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-medium text-gray-400 uppercase tracking-wider">
            Proiezione Esterna
          </span>
          <span className="text-[10px] text-gray-400">
            {settings.projectionMode === 'dual' ? '✨ Doppio Proiettore (7m)' : '🖥️ Singolo Proiettore'}
          </span>
        </div>

        {/* Mode Selector Tabs: Single vs Dual */}
        <div className="grid grid-cols-2 gap-1.5 p-1 bg-gray-900/90 rounded-lg border border-gray-750">
          <button
            type="button"
            disabled={isProjectionOpen}
            onClick={() => updateSettings({ projectionMode: 'single' })}
            className={`py-1.5 px-2 rounded text-xs font-semibold cursor-pointer transition-all ${
              settings.projectionMode !== 'dual'
                ? 'bg-blue-600 text-white shadow'
                : 'text-gray-400 hover:text-white'
            } disabled:opacity-50`}
          >
            🖥️ Proiettore Singolo
          </button>
          <button
            type="button"
            disabled={isProjectionOpen}
            onClick={() => updateSettings({ projectionMode: 'dual' })}
            className={`py-1.5 px-2 rounded text-xs font-semibold cursor-pointer transition-all ${
              settings.projectionMode === 'dual'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-gray-400 hover:text-white'
            } disabled:opacity-50`}
          >
            🖥️🖥️ Doppio (Parete 7m)
          </button>
        </div>

        {/* Single Mode: 1 Monitor Selector */}
        {settings.projectionMode !== 'dual' ? (
          <div>
            <label className="text-xs text-gray-400 block mb-1">Schermo / Proiettore</label>
            <select
              value={selectedMonitor}
              onChange={(e) => setSelectedMonitor(Number(e.target.value))}
              disabled={isProjectionOpen}
              className="w-full bg-gray-700 text-white text-sm rounded px-2 py-1.5 disabled:opacity-50"
            >
              {monitors.map((m, i) => (
                <option key={i} value={i}>
                  {m.name || `Monitor ${i + 1}`} ({m.size.width}x{m.size.height})
                </option>
              ))}
              {monitors.length === 0 && <option>Nessun monitor rilevato</option>}
            </select>
          </div>
        ) : (
          /* Dual Mode: 2 Monitor Selectors & Calibration */
          <div className="flex flex-col gap-2.5 bg-gray-900/50 p-2.5 rounded-lg border border-gray-750">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] text-gray-400 block mb-1 font-medium">
                  👈 Proiettore SX (Metà SX)
                </label>
                <select
                  value={settings.leftMonitorIndex ?? 0}
                  onChange={(e) => updateSettings({ leftMonitorIndex: Number(e.target.value) })}
                  disabled={isProjectionOpen}
                  className="w-full bg-gray-750 text-white text-xs rounded px-2 py-1.5 disabled:opacity-50"
                >
                  {monitors.map((m, i) => (
                    <option key={i} value={i}>
                      {m.name || `Monitor ${i + 1}`} ({m.size.width}x{m.size.height})
                    </option>
                  ))}
                  {monitors.length === 0 && <option>Nessun monitor</option>}
                </select>
              </div>

              <div>
                <label className="text-[11px] text-gray-400 block mb-1 font-medium">
                  👉 Proiettore DX (Metà DX)
                </label>
                <select
                  value={settings.rightMonitorIndex ?? (monitors.length > 1 ? 1 : 0)}
                  onChange={(e) => updateSettings({ rightMonitorIndex: Number(e.target.value) })}
                  disabled={isProjectionOpen}
                  className="w-full bg-gray-750 text-white text-xs rounded px-2 py-1.5 disabled:opacity-50"
                >
                  {monitors.map((m, i) => (
                    <option key={i} value={i}>
                      {m.name || `Monitor ${i + 1}`} ({m.size.width}x{m.size.height})
                    </option>
                  ))}
                  {monitors.length === 0 && <option>Nessun monitor</option>}
                </select>
              </div>
            </div>

            {monitors.length < 2 && (
              <div className="text-[10px] text-yellow-400/90 bg-yellow-950/30 p-1.5 rounded border border-yellow-800/40">
                💡 Nota: Rilevato 1 monitor. Per la proiezione reale su 7m collega entrambi i proiettori (HDMI/DP). In test, entrambe le metà si apriranno su questo schermo.
              </div>
            )}

            {/* Overlap Calibration Slider */}
            <div className="pt-1 border-t border-gray-800">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-gray-300 font-medium">Sovrapposizione centrale (Overlap):</span>
                <span className="font-semibold text-indigo-300">{settings.centerOverlap ?? 0}px</span>
              </div>
              <input
                type="range"
                min={0}
                max={250}
                step={2}
                value={settings.centerOverlap ?? 0}
                onChange={(e) => updateSettings({ centerOverlap: Number(e.target.value) })}
                className="w-full accent-indigo-500"
              />
              <div className="flex justify-between text-[10px] text-gray-500 mb-1.5">
                <span>0px (Affiancati)</span>
                <span>80px</span>
                <span>160px</span>
                <span>250px</span>
              </div>

              <div className="flex items-center gap-1 mb-2">
                {[0, 30, 60, 100].map((px) => (
                  <button
                    key={px}
                    type="button"
                    onClick={() => updateSettings({ centerOverlap: px })}
                    className={`flex-1 text-[10px] py-0.5 rounded cursor-pointer transition-colors border ${
                      (settings.centerOverlap ?? 0) === px
                        ? 'bg-indigo-600/40 border-indigo-500 text-white font-semibold'
                        : 'bg-gray-800 border-gray-700 text-gray-400 hover:text-white hover:bg-gray-700'
                    }`}
                  >
                    {px === 0 ? '0px' : `${px}px`}
                  </button>
                ))}
              </div>

              {/* Edge Blend Toggle */}
              <label className="flex items-center gap-2 cursor-pointer select-none mt-1">
                <input
                  type="checkbox"
                  checked={settings.edgeBlend ?? false}
                  onChange={(e) => updateSettings({ edgeBlend: e.target.checked })}
                  className="rounded accent-indigo-500 cursor-pointer w-4 h-4"
                />
                <div className="flex flex-col">
                  <span className="text-xs text-gray-200 font-medium">
                    ✨ Sfumatura morbida giunzione (*Edge Blending*)
                  </span>
                  <span className="text-[10px] text-gray-400">
                    Evita bande luminose sovrapponendo i fasci con gradiente morbido
                  </span>
                </div>
              </label>
            </div>
          </div>
        )}

        {/* Projection Action Button */}
        <button
          onClick={handleOpenProjection}
          disabled={monitors.length === 0}
          className={`w-full py-2.5 rounded text-sm font-semibold transition-colors cursor-pointer shadow ${
            isProjectionOpen
              ? 'bg-red-600 hover:bg-red-700 text-white'
              : settings.projectionMode === 'dual'
              ? 'bg-indigo-600 hover:bg-indigo-500 text-white'
              : 'bg-blue-600 hover:bg-blue-500 text-white'
          } disabled:opacity-50 disabled:cursor-not-allowed`}
        >
          {isProjectionOpen
            ? '⏏ Chiudi Proiezione'
            : settings.projectionMode === 'dual'
            ? '🖥️🖥️ Avvia Proiezione a 2 Proiettori (7 Metri)'
            : '🖥️ Apri su Proiettore Singolo'}
        </button>
      </div>
    </div>
  );
}
