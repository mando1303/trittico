import { useState, useEffect } from 'react';
import { open } from '@tauri-apps/plugin-dialog';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { useStore } from '../../stores/useStore';

export default function ImportZone() {
  const addImages = useStore((s) => s.addImages);
  const addAudioTracks = useStore((s) => s.addAudioTracks);
  const activeTab = useStore((s) => s.activeTab);
  const images = useStore((s) => s.images);
  const audioTracks = useStore((s) => s.audioTracks);

  const isAudioTab = activeTab === 'audio';
  const hasItems = isAudioTab ? audioTracks.length > 0 : images.length > 0;

  const [isDragOver, setIsDragOver] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  // Listen for native OS file drag & drop
  useEffect(() => {
    let unlisten: (() => void) | undefined;
    async function setupDragDrop() {
      try {
        const win = getCurrentWindow();
        unlisten = await win.onDragDropEvent((event) => {
          if (event.payload.type === 'over') {
            setIsDragOver(true);
          } else if (event.payload.type === 'drop') {
            setIsDragOver(false);
            const paths = event.payload.paths;
            if (paths && paths.length > 0) {
              const imageExtensions = ['.jpg', '.jpeg', '.png', '.webp', '.bmp', '.gif'];
              const audioExtensions = ['.mp3', '.wav', '.ogg', '.flac', '.aac', '.m4a'];

              const imageFiles = paths.filter((p) =>
                imageExtensions.some((ext) => p.toLowerCase().endsWith(ext))
              );
              const audioFiles = paths.filter((p) =>
                audioExtensions.some((ext) => p.toLowerCase().endsWith(ext))
              );

              if (imageFiles.length > 0) {
                addImages(imageFiles);
              }
              if (audioFiles.length > 0) {
                addAudioTracks(audioFiles);
              }
              setIsExpanded(false);
            }
          } else {
            setIsDragOver(false);
          }
        });
      } catch (err) {
        console.warn('Drag drop listener setup:', err);
      }
    }
    setupDragDrop();
    return () => {
      if (unlisten) unlisten();
    };
  }, [addImages, addAudioTracks]);

  const handleImport = async () => {
    try {
      if (isAudioTab) {
        const selected = await open({
          multiple: true,
          filters: [
            {
              name: 'File Audio',
              extensions: ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'],
            },
          ],
        });
        if (selected) {
          const paths = Array.isArray(selected) ? selected : [selected];
          addAudioTracks(paths);
          setIsExpanded(false);
        }
      } else {
        const selected = await open({
          multiple: true,
          filters: [
            {
              name: 'Immagini',
              extensions: ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'gif'],
            },
          ],
        });
        if (selected) {
          const paths = Array.isArray(selected) ? selected : [selected];
          addImages(paths);
          setIsExpanded(false);
        }
      }
    } catch (err) {
      console.error('Error opening file dialog:', err);
    }
  };

  // When items are loaded and not expanded or dragging, render compact collapsible buttons
  if (hasItems && !isExpanded && !isDragOver) {
    return (
      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={handleImport}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all flex items-center gap-1.5 shadow ${
            isAudioTab
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/30'
              : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-900/30'
          }`}
          title={isAudioTab ? 'Seleziona file audio da aggiungere' : 'Seleziona foto da aggiungere'}
        >
          <span>{isAudioTab ? '🎵' : '➕'}</span>
          <span>{isAudioTab ? 'Aggiungi Audio' : 'Aggiungi Foto'}</span>
        </button>

        <button
          type="button"
          onClick={() => setIsExpanded(true)}
          className="px-2.5 py-1.5 rounded-lg text-xs text-gray-300 hover:text-white bg-gray-850 hover:bg-gray-750 border border-gray-700 cursor-pointer transition-colors flex items-center gap-1"
          title="Espandi l'area di trascinamento per rilasciare i file"
        >
          <span>📥</span>
          <span className="text-[11px]">Trascina file ▾</span>
        </button>
      </div>
    );
  }

  // Expanded drop zone (or when empty or dragging files)
  return (
    <div className="w-full relative transition-all duration-200">
      {hasItems && (
        <button
          type="button"
          onClick={() => setIsExpanded(false)}
          className="absolute top-2 right-2 z-10 px-2 py-1 text-[10px] text-gray-400 hover:text-white bg-gray-800/90 hover:bg-gray-700 rounded border border-gray-700 cursor-pointer transition-colors flex items-center gap-1 shadow"
          title="Riduci l'area per guadagnare spazio per le miniature"
        >
          <span>▴</span>
          <span>Riduci spazio</span>
        </button>
      )}

      <button
        type="button"
        onClick={handleImport}
        className={`w-full border-2 border-dashed rounded-lg p-3.5 text-center transition-all cursor-pointer ${
          isDragOver
            ? 'border-blue-400 bg-blue-500/25 scale-[1.01]'
            : isAudioTab
            ? 'border-emerald-700/60 hover:border-emerald-500 hover:bg-emerald-500/10'
            : 'border-gray-600 hover:border-blue-500 hover:bg-blue-500/10'
        }`}
      >
        <div className="text-xl mb-1">{isDragOver ? '📥' : isAudioTab ? '🎵' : '📁'}</div>
        <div className="text-xs font-semibold text-gray-200">
          {isDragOver
            ? 'Rilascia qui i file!'
            : isAudioTab
            ? 'Clicca per importare o trascina qui i file Audio'
            : 'Clicca per importare o trascina qui le Foto'}
        </div>
        <div className="text-[10px] text-gray-400 mt-0.5">
          {isAudioTab ? 'MP3, WAV, OGG, FLAC, AAC, M4A' : 'JPG, PNG, WEBP, BMP, GIF'}
        </div>
      </button>
    </div>
  );
}
