import { useState } from 'react';
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  rectSortingStrategy,
} from '@dnd-kit/sortable';
import { useStore } from '../../stores/useStore';
import GalleryItem from './GalleryItem';

export default function Gallery() {
  const images = useStore((s) => s.images);
  const reorderImages = useStore((s) => s.reorderImages);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: { distance: 5 },
    })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      const oldIndex = images.findIndex((img) => img.id === active.id);
      const newIndex = images.findIndex((img) => img.id === over.id);
      reorderImages(oldIndex, newIndex);
    }
  };

  const [thumbSize, setThumbSize] = useState<'sm' | 'md' | 'lg'>('md');

  if (images.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center text-gray-500">
        <p>Nessuna immagine. Importa delle immagini per iniziare.</p>
      </div>
    );
  }

  const gridClass =
    thumbSize === 'sm'
      ? 'grid grid-cols-[repeat(auto-fill,minmax(105px,1fr))] gap-2'
      : thumbSize === 'lg'
      ? 'grid grid-cols-[repeat(auto-fill,minmax(185px,1fr))] gap-3'
      : 'grid grid-cols-[repeat(auto-fill,minmax(140px,1fr))] gap-2.5';

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="flex items-center justify-between text-xs text-gray-400 mb-2.5 pb-1 border-b border-gray-800">
        <div>
          <span>{images.length} {images.length === 1 ? 'immagine' : 'immagini'}</span>
          <span className="mx-1.5">•</span>
          <span className="text-[11px] text-gray-500">Trascina per riordinare</span>
        </div>

        {/* Thumbnail Size Controls */}
        <div className="flex items-center gap-1.5 bg-gray-900 px-2 py-0.5 rounded-lg border border-gray-800">
          <span className="text-[10px] text-gray-400">Miniature:</span>
          <button
            type="button"
            onClick={() => setThumbSize('sm')}
            className={`px-1.5 py-0.5 rounded text-[10px] font-semibold cursor-pointer transition-colors ${
              thumbSize === 'sm' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'
            }`}
            title="Miniature Compatte (Massimo numero di foto visibili)"
          >
            Piccole (S)
          </button>
          <button
            type="button"
            onClick={() => setThumbSize('md')}
            className={`px-1.5 py-0.5 rounded text-[10px] font-semibold cursor-pointer transition-colors ${
              thumbSize === 'md' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'
            }`}
            title="Miniature Medie (Bilanciate)"
          >
            Medie (M)
          </button>
          <button
            type="button"
            onClick={() => setThumbSize('lg')}
            className={`px-1.5 py-0.5 rounded text-[10px] font-semibold cursor-pointer transition-colors ${
              thumbSize === 'lg' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'
            }`}
            title="Miniature Grandi (Dettagliate)"
          >
            Grandi (L)
          </button>
        </div>
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        <SortableContext items={images.map((i) => i.id)} strategy={rectSortingStrategy}>
          <div className={gridClass}>
            {images.map((image, index) => (
              <GalleryItem key={image.id} image={image} index={index} />
            ))}
          </div>
        </SortableContext>
      </DndContext>
    </div>
  );
}
