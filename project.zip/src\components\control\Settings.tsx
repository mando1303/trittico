import { useStore } from '../../stores/useStore';

export default function Settings() {
  const settings = useStore((s) => s.settings);
  const updateSettings = useStore((s) => s.updateSettings);
  const images = useStore((s) => s.images);
  const clearImages = useStore((s) => s.clearImages);

  return (
    <div className="bg-gray-800/50 rounded-lg p-4 flex flex-col gap-3">
      <h2 className="text-sm font-semibold text-gray-300 uppercase tracking-wider">Impostazioni</h2>

      {/* Interval */}
      <div>
        <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
          <span>Intervallo globale predefinito: <strong className="text-white">{settings.interval}s</strong></span>
        </div>
        <input
          type="range"
          min={1}
          max={60}
          step={1}
          value={settings.interval}
          onChange={(e) => updateSettings({ interval: Number(e.target.value) })}
          className="w-full accent-blue-500 cursor-pointer"
        />
        <div className="flex justify-between text-xs text-gray-500">
          <span>1s</span>
          <span>60s</span>
        </div>
        <p className="text-[10px] text-sky-300/90 mt-1.5 bg-sky-950/40 border border-sky-800/40 p-1.5 rounded flex items-start gap-1.5 leading-snug">
          <span className="text-xs">⏱️</span>
          <span><strong>Personalizzazione a comando:</strong> per far durare una singola foto più o meno a lungo (es. 8s anziché 5s), clicca sull'icona <strong>⏱️</strong> nella miniatura della foto.</span>
        </p>
      </div>

      {/* Fade duration */}
      <div>
        <label className="text-xs text-gray-400 block mb-1">
          Durata dissolvenza: {settings.fadeDuration}ms
        </label>
        <input
          type="range"
          min={200}
          max={3000}
          step={100}
          value={settings.fadeDuration}
          onChange={(e) => updateSettings({ fadeDuration: Number(e.target.value) })}
          className="w-full accent-blue-500"
        />
        <div className="flex justify-between text-xs text-gray-500">
          <span>200ms</span>
          <span>3000ms</span>
        </div>
      </div>

      {/* Spacing & Margins section */}
      <div className="border-t border-gray-700/60 pt-3 flex flex-col gap-3">
        <span className="text-xs font-semibold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
          <span>🖼️</span>
          <span>Bordi e Spaziature Schermo</span>
        </span>

        {/* Panel gap (Margine tra pannelli) */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-xs text-gray-400 block">
              Spazio tra i 3 pannelli: {settings.panelGap ?? 0}px
            </label>
            <button
              type="button"
              onClick={() => updateSettings({ panelGap: 0 })}
              className={`text-[10px] px-1.5 py-0.5 rounded cursor-pointer transition-colors ${
                (settings.panelGap ?? 0) === 0
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
              title="Azzera lo spazio per pannelli adiacenti"
            >
              0px (Uniti)
            </button>
          </div>
          <input
            type="range"
            min={0}
            max={40}
            step={1}
            value={settings.panelGap ?? 0}
            onChange={(e) => updateSettings({ panelGap: Number(e.target.value) })}
            className="w-full accent-blue-500"
          />
          <div className="flex justify-between text-[10px] text-gray-500">
            <span>0px (Accostati)</span>
            <span>20px</span>
            <span>40px</span>
          </div>
        </div>

        {/* Outer Margin (Margine esterno tra trittico e bordi dello schermo) */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-xs text-gray-400 block">
              Margine esterno schermo: {settings.outerMargin ?? 0}px
            </label>
            <button
              type="button"
              onClick={() => updateSettings({ outerMargin: 0 })}
              className={`text-[10px] px-1.5 py-0.5 rounded cursor-pointer transition-colors ${
                (settings.outerMargin ?? 0) === 0
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
              title="Rimuovi margini esterni per visualizzazione a schermo intero senza bordi"
            >
              0px (Pieno schermo)
            </button>
          </div>
          <input
            type="range"
            min={0}
            max={120}
            step={2}
            value={settings.outerMargin ?? 0}
            onChange={(e) => updateSettings({ outerMargin: Number(e.target.value) })}
            className="w-full accent-blue-500"
          />
          <div className="flex justify-between text-[10px] text-gray-500 mb-1">
            <span>0px (Tutto schermo)</span>
            <span>30px</span>
            <span>60px</span>
            <span>120px</span>
          </div>
          <div className="flex items-center gap-1.5 pt-0.5">
            {[0, 16, 32, 64].map((px) => (
              <button
                key={px}
                type="button"
                onClick={() => updateSettings({ outerMargin: px })}
                className={`flex-1 text-[10px] py-0.5 rounded cursor-pointer transition-colors border ${
                  (settings.outerMargin ?? 0) === px
                    ? 'bg-blue-600/40 border-blue-500 text-white font-medium'
                    : 'bg-gray-800 border-gray-700 text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
              >
                {px === 0 ? '0px' : `${px}px`}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Clear gallery */}
      {images.length > 0 && (
        <button
          onClick={clearImages}
          className="w-full py-1.5 rounded text-sm bg-gray-700 hover:bg-red-600/80 
                     text-gray-300 hover:text-white transition-colors cursor-pointer mt-2"
        >
          🗑️ Svuota galleria ({images.length} immagini)
        </button>
      )}
    </div>
  );
}
