export type PanelPosition = 'any' | 'random' | 'left' | 'center' | 'right';

export interface GalleryImage {
  id: string;
  path: string;
  assetUrl: string;
  name: string;
  pairedImageId?: string; // ID of the image that must follow in the adjacent panel
  targetPanel?: PanelPosition; // Position constraint: left, center, right, or any
  customDuration?: number; // Custom appearance duration in seconds (optional)
}

export interface SlideshowSettings {
  interval: number;        // seconds between panel changes
  fadeDuration: number;    // fade transition duration in ms  
  fitMode: 'contain';      // always contain (scaled and adapted)
  mode: 'sequential' | 'shuffle' | 'random';  // slideshow mode
  panelGap: number;        // gap in pixels between panels (0 = seamless)
  outerMargin?: number;    // outer margin in pixels around the entire triptych (default: 0)
  playImages?: boolean;    // whether images advance during playback (default: true)
  continuous?: boolean;    // whether images loop continuously (default: true)
  projectionMode?: 'single' | 'dual'; // projection mode: single or dual projector (default: 'single')
  leftMonitorIndex?: number;          // monitor index for left projector in dual mode
  rightMonitorIndex?: number;         // monitor index for right projector in dual mode
  centerOverlap?: number;             // center overlap in pixels between the 2 projectors (default: 0)
  edgeBlend?: boolean;                // whether soft edge blending gradient is enabled (default: false)
}

export interface TriptychState {
  panels: [string | null, string | null, string | null];
  activePanel: 0 | 1 | 2;
  currentImageIndex: number;
  pendingPairedImageId?: string | null;
  lastChangedImageId?: string | null;
  stepCount: number;
  panelImageIds?: [string | null, string | null, string | null];
  panelStartTimes?: [number, number, number];
  panelDurations?: [number, number, number];
}

export interface AlbumImageRecord {
  id: string;
  path: string;
  name: string;
  pairedImageId?: string;
  targetPanel?: PanelPosition;
  customDuration?: number;
}

export interface AudioTrack {
  id: string;
  path: string;
  assetUrl: string;
  name: string;
  duration?: number;
}

export interface AudioSettings {
  enabled: boolean;
  mode: 'sequential' | 'shuffle';
  volume: number; // 0 to 2.5 (0% to 250%, with hardware/software boost above 1.0)
  continuous?: boolean; // whether audio loops continuously (default: true)
}

export interface AlbumAudioRecord {
  id: string;
  path: string;
  name: string;
}

export interface AlbumData {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  images: AlbumImageRecord[];
  audioTracks?: AlbumAudioRecord[];
  audioSettings?: AudioSettings;
  settings: SlideshowSettings;
}

