import { AnimatePresence, motion } from 'framer-motion';

interface Props {
  imageUrl: string | null;
  fadeDuration: number;
  isChanging: boolean;
}

export function Panel({ imageUrl, fadeDuration }: Props) {
  const durationSec = fadeDuration / 1000;

  return (
    <div className="flex-1 flex items-center justify-center bg-black overflow-hidden relative">
      <AnimatePresence mode="wait">
        {imageUrl && (
          <motion.img
            key={imageUrl}
            src={imageUrl}
            alt=""
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: durationSec, ease: 'easeInOut' }}
            className="w-full h-full object-contain absolute inset-0"
            draggable={false}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
