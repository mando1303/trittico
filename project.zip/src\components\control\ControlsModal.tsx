import { motion } from 'framer-motion';
import { useStore } from '../../stores/useStore';
import Preview from './Preview';
import Controls from './Controls';
import Settings from './Settings';

interface ControlsModalProps {
  onClose: () => void;
  isDocked: boolean;
  onToggleDock: () => void;
}

export default function ControlsModal({
  onClose,
  isDocked,
  onToggleDock,
}: ControlsModalProps) {
  const isPlaying = useStore((s) => s.isPlaying);
  const isProjectionOpen = useStore((s) => s.isProjectionOpen);
  const settings = useStore((s) => s.settings);

  // If docked as sidebar
  if (isDocked) {
    return (
      <aside className="w-84 shrink-0 flex flex-col gap-3 bg-gray-900/60 p-3 rounded-xl border border-gray-800/80 max-h-[calc(100vh-100px)] overflow-y-auto">
        {/* Titlebar with Unpin & Close */}
        <div className="flex items-center justify-between pb-2 border-b border-gray-800">
          <div className="flex items-center gap-2">
            <span className="text-sm">🎛️</span>
            <span className="text-xs font-bold text-gray-200 uppercase tracking-wider">
              Controlli & Proiezione
            </span>
          </div>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={onToggleDock}
              className="p-1 text-gray-400 hover:text-blue-400 hover:bg-gray-800 rounded transition-colors cursor-pointer"
              title="Sblocca come finestra mobile flottante"
            >
              <span className="text-xs">⧉ Flottante</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1 text-gray-400 hover:text-white hover:bg-gray-800 rounded transition-colors cursor-pointer"
              title="Chiudi pannello controlli (premi C per riaprirlo)"
            >
              <span className="text-sm font-bold leading-none">✕</span>
            </button>
          </div>
        </div>

        <Preview />
        <Controls />
        <Settings />
      </aside>
    );
  }

  // Floating draggable window
  return (
    <motion.div
      drag
      dragMomentum={false}
      initial={{ opacity: 0, scale: 0.95, y: 15 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, y: 15 }}
      transition={{ duration: 0.18 }}
      className="fixed top-16 right-8 z-40 w-88 max-h-[calc(100vh-90px)] bg-[#141419]/98 text-white rounded-2xl shadow-2xl border border-gray-700/80 backdrop-blur-lg flex flex-col select-none overflow-hidden"
      style={{ boxShadow: '0 20px 50px rgba(0,0,0,0.85)' }}
    >
      {/* Titlebar / Drag Handle */}
      <div className="flex items-center justify-between px-3.5 py-2.5 bg-gray-800/90 border-b border-gray-700/80 cursor-move shrink-0">
        <div className="flex items-center gap-2">
          <span className="text-gray-400 text-sm font-mono cursor-grab active:cursor-grabbing" title="Trascina per spostare">
            ⠿
          </span>
          <span className="text-xs font-bold tracking-wide text-gray-100 flex items-center gap-1.5">
            <span>🎛️</span>
            <span>Controlli & Proiezione</span>
          </span>
          {isPlaying && (
            <span className="flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-green-950/80 text-green-400 border border-green-700/50">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
              <span>Play</span>
            </span>
          )}
          {isProjectionOpen && (
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-indigo-950/80 text-indigo-300 border border-indigo-700/50">
              {settings.projectionMode === 'dual' ? '2 Proiettori' : 'Proiezione'}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1" onPointerDown={(e) => e.stopPropagation()}>
          <button
            type="button"
            onClick={onToggleDock}
            className="p-1 px-1.5 text-gray-400 hover:text-blue-300 hover:bg-gray-700/60 rounded text-[11px] transition-colors cursor-pointer flex items-center gap-1"
            title="Blocca sul lato destro"
          >
            <span>📌</span>
            <span className="text-[10px]">Blocca a lato</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-white hover:bg-red-600/80 rounded transition-colors cursor-pointer w-6 h-6 flex items-center justify-center"
            title="Chiudi finestra controlli (tasto C o Esc)"
          >
            <span className="text-xs font-bold leading-none">✕</span>
          </button>
        </div>
      </div>

      {/* Body containing all 3 modules */}
      <div
        className="p-3.5 flex flex-col gap-3 overflow-y-auto flex-1 overscroll-contain"
        onPointerDown={(e) => e.stopPropagation()}
      >
        <Preview />
        <Controls />
        <Settings />
      </div>
    </motion.div>
  );
}
