import { AnimatePresence, motion } from 'framer-motion';
import { useStore } from '../../stores/useStore';
import { openCleanFullscreenPreview } from '../../utils/previewWindow';

export default function Preview() {
  const triptych = useStore((s) => s.triptych);
  const images = useStore((s) => s.images);
  const settings = useStore((s) => s.settings);
  const isPlaying = useStore((s) => s.isPlaying);

  // Show first 3 images as preview if slideshow hasn't started
  const displayPanels = triptych.panels[0]
    ? triptych.panels
    : [
        images[0]?.assetUrl || null,
        images[1]?.assetUrl || null,
        images[2]?.assetUrl || null,
      ];

  const durationSec = settings.fadeDuration / 1000;

  const customDurationsOnScreen = (triptych.panelDurations || []).filter((d) => d > 0);

  return (
    <div className="bg-gray-800/50 rounded-lg p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h2 className="text-sm font-semibold text-gray-300 uppercase tracking-wider">
            Anteprima Risultato
          </h2>
          {settings.projectionMode === 'dual' && (
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-900/60 text-indigo-300 border border-indigo-700/60 font-medium">
              2 Proiettori (7m)
            </span>
          )}
        </div>
        <button
          onClick={openCleanFullscreenPreview}
          className="text-xs font-medium text-blue-400 hover:text-blue-300 flex items-center gap-1 cursor-pointer transition-colors"
          title="Apri anteprima pulita a schermo intero per vedere il risultato finale (Esc per chiudere)"
        >
          <span>⛶ Ingrandisci</span>
        </button>
      </div>

      <div
        onClick={openCleanFullscreenPreview}
        style={{
          gap: `${Math.min(settings.panelGap ?? 0, 6)}px`,
          padding: `${Math.round(((settings.outerMargin ?? 0) / 120) * 14)}px`,
        }}
        className="flex bg-black rounded overflow-hidden aspect-[3/1] border border-gray-700/50 relative cursor-pointer hover:border-blue-500 transition-all duration-200 group box-border"
      >
        {displayPanels.map((url, i) => (
          <div key={i} className="flex-1 flex items-center justify-center relative overflow-hidden bg-black">
            <AnimatePresence mode="wait">
              {url ? (
                <motion.img
                  key={url}
                  src={url}
                  alt={`Pannello ${i + 1}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: durationSec, ease: 'easeInOut' }}
                  className="w-full h-full object-contain absolute inset-0 select-none pointer-events-none"
                  draggable={false}
                />
              ) : (
                <div className="text-gray-600 text-xs">
                  {images.length === 0 ? '—' : `P${i + 1}`}
                </div>
              )}
            </AnimatePresence>
          </div>
        ))}

        {/* Hover overlay hint */}
        {images.length >= 3 && (
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity pointer-events-none">
            <span className="text-xs bg-black/80 text-white px-2 py-1 rounded shadow">
              🔍 Clicca per vedere il risultato a schermo intero
            </span>
          </div>
        )}
      </div>

      {/* Active panel indicators */}
      <div className="flex items-center justify-between text-[11px] text-gray-400 mt-0.5">
        <div className="flex items-center gap-1.5 flex-1">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className={`flex-1 h-1.5 rounded-full transition-colors ${
                triptych.panels[0] && triptych.activePanel === i ? 'bg-blue-500' : 'bg-gray-700'
              }`}
              title={`Pannello ${i + 1}`}
            />
          ))}
        </div>
        <div className="ml-2 flex items-center gap-1.5 text-[10px] shrink-0">
          <span className={isPlaying ? 'text-green-400 font-medium' : 'text-gray-400'}>
            {isPlaying ? '▶ In riproduzione' : '⏸ In pausa'}
          </span>
          {isPlaying && (
            <div className="flex items-center gap-1">
              <span
                className="px-1.5 py-0.5 rounded font-semibold bg-gray-800 text-gray-300"
                title="Durata intervallo generale tra cambi foto"
              >
                ⏱️ {settings.interval}s
              </span>
              {customDurationsOnScreen.length > 0 && (
                <span
                  className="px-1.5 py-0.5 rounded font-semibold bg-sky-500/20 text-sky-300 border border-sky-500/40 text-[9px]"
                  title="Una o più foto sul trittico hanno una durata estesa e rimarranno visibili più a lungo"
                >
                  🔒 Foto {customDurationsOnScreen.join(', ')}s
                </span>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
