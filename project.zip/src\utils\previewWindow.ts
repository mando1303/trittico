import { WebviewWindow } from '@tauri-apps/api/webviewWindow';
import { emit } from '@tauri-apps/api/event';

/**
 * Opens a pristine, 100% native borderless fullscreen window
 * to preview the final triptych presentation without distorting
 * or affecting the main workspace or detached controls window.
 */
export async function openCleanFullscreenPreview() {
  try {
    const existing = await WebviewWindow.getByLabel('preview_fullscreen');
    if (existing) {
      await existing.show();
      await existing.setFocus();
      emit('request-triptych-update', {}).catch((e) => console.warn(e));
      return;
    }

    const win = new WebviewWindow('preview_fullscreen', {
      url: '/?window=projection&role=single&preview=true',
      title: 'Triptych - Anteprima Risultato Finale',
      fullscreen: true,
      decorations: false,
      alwaysOnTop: true,
      skipTaskbar: false,
    });

    win.once('tauri://created', () => {
      setTimeout(() => {
        emit('request-triptych-update', {}).catch((e) => console.warn(e));
      }, 100);
    });

    win.once('tauri://error', (err) => {
      console.error('Error creating preview window:', err);
    });
  } catch (err) {
    console.error('Error opening clean preview window:', err);
  }
}
