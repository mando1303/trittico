import { useEffect, useState } from 'react';
import { emit, listen } from '@tauri-apps/api/event';
import { getCurrentWindow } from '@tauri-apps/api/window';

interface SlideshowSyncState {
  isPlaying: boolean;
  activePanel: number;
  interval: number;
  mode: string;
  hasImages: boolean;
}

export default function ControllerApp() {
  const [state, setState] = useState<SlideshowSyncState>({
    isPlaying: false,
    activePanel: 0,
    interval: 5,
    mode: 'shuffle',
    hasImages: true,
  });

  useEffect(() => {
    // Listen to updates from main window
    const unlistenState = listen<SlideshowSyncState>('slideshow-state', (event) => {
      setState(event.payload);
    });

    // Request initial state from main window
    emit('request-slideshow-state', {});

    return () => {
      unlistenState.then((fn) => fn());
    };
  }, []);

  const sendAction = (action: 'toggle-play' | 'advance' | 'stop') => {
    emit('slideshow-control', { action });
  };

  const handleClose = async () => {
    try {
      const win = getCurrentWindow();
      await win.close();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="h-screen w-screen bg-[#141419] text-white p-4 flex flex-col justify-between select-none border border-gray-800">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-2.5">
        <div className="flex items-center gap-2">
          <span className="text-base">🎬</span>
          <span className="text-xs font-bold tracking-wide uppercase text-gray-200">
            Telecomando Triptych
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <span
            className={`w-2.5 h-2.5 rounded-full ${
              state.isPlaying ? 'bg-green-500 animate-pulse' : 'bg-yellow-500'
            }`}
          />
          <span className="text-[11px] font-semibold text-gray-300">
            {state.isPlaying ? 'In Riproduzione' : 'In Pausa'}
          </span>
        </div>
      </div>

      {/* Center: Panels status & Mode */}
      <div className="flex flex-col gap-3 py-2">
        <div className="bg-gray-900/90 p-3 rounded-lg border border-gray-800">
          <div className="text-[10px] text-gray-400 uppercase tracking-wider mb-2 font-semibold text-center">
            Prossimo pannello in transizione
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            {[
              { idx: 0, label: '1 • Sinistra' },
              { idx: 1, label: '2 • Centro' },
              { idx: 2, label: '3 • Destra' },
            ].map((p) => {
              const isActive = state.activePanel === p.idx;
              return (
                <div
                  key={p.idx}
                  className={`py-2 px-1 rounded text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-blue-600 text-white font-bold shadow-lg shadow-blue-500/30 ring-1 ring-blue-400 scale-[1.02]'
                      : 'bg-gray-800/80 text-gray-400 border border-gray-700/60'
                  }`}
                >
                  {p.label}
                </div>
              );
            })}
          </div>
        </div>

        <div className="text-center text-[11px] text-gray-400">
          Modalità: <strong className="text-gray-200 capitalize">{state.mode}</strong> • Intervallo:{' '}
          <strong className="text-gray-200">{state.interval}s</strong>
        </div>
      </div>

      {/* Buttons */}
      <div className="flex flex-col gap-2">
        <button
          onClick={() => sendAction('toggle-play')}
          className={`w-full py-3 rounded-lg text-sm font-bold cursor-pointer transition-all shadow ${
            state.isPlaying
              ? 'bg-yellow-600 hover:bg-yellow-500 text-white'
              : 'bg-gray-700 hover:bg-gray-600 text-white border border-gray-600'
          }`}
        >
          {state.isPlaying ? '⏸ Metti in Pausa' : '▶ Avvia Slideshow'}
        </button>

        <div className="flex gap-2">
          <button
            onClick={() => sendAction('advance')}
            className="flex-1 py-2.5 bg-gray-700 hover:bg-gray-600 text-white text-xs font-semibold rounded-lg cursor-pointer transition-colors shadow flex items-center justify-center gap-1.5"
            title="Avanza manualmente al prossimo pannello"
          >
            <span>⏭</span>
            <span>Avanza Pannello</span>
          </button>

          <button
            onClick={() => sendAction('stop')}
            className="px-4 py-2.5 bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white text-xs font-semibold rounded-lg border border-gray-700 cursor-pointer transition-colors"
            title="Stop slideshow"
          >
            ⏹ Stop
          </button>
        </div>

        <button
          onClick={handleClose}
          className="w-full mt-1 py-1 text-gray-500 hover:text-gray-300 text-[11px] transition-colors cursor-pointer"
        >
          Chiudi questa finestra
        </button>
      </div>
    </div>
  );
}
