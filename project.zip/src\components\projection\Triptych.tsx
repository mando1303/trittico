import { useState, useEffect } from 'react';
import { listen, emit } from '@tauri-apps/api/event';
import { Panel } from './Panel';

interface TriptychUpdate {
  panels: [string | null, string | null, string | null];
  activePanel: number;
  fadeDuration: number;
  panelGap?: number;
  outerMargin?: number;
  centerOverlap?: number;
  edgeBlend?: boolean;
}

interface Props {
  role?: 'single' | 'left' | 'right';
}

export function Triptych({ role = 'single' }: Props) {
  const [panels, setPanels] = useState<[string | null, string | null, string | null]>([null, null, null]);
  const [fadeDuration, setFadeDuration] = useState(1000);
  const [panelGap, setPanelGap] = useState(0);
  const [outerMargin, setOuterMargin] = useState(0);
  const [overlap, setOverlap] = useState(0);
  const [edgeBlend, setEdgeBlend] = useState(false);
  const [changingPanel, setChangingPanel] = useState<number | null>(null);

  useEffect(() => {
    const unlisten = listen<TriptychUpdate>('triptych-update', (event) => {
      const data = event.payload;
      setFadeDuration(data.fadeDuration);
      if (typeof data.panelGap === 'number') {
        setPanelGap(data.panelGap);
      }
      if (typeof data.outerMargin === 'number') {
        setOuterMargin(data.outerMargin);
      }
      if (typeof data.centerOverlap === 'number') {
        setOverlap(data.centerOverlap);
      }
      if (typeof data.edgeBlend === 'boolean') {
        setEdgeBlend(data.edgeBlend);
      }
      
      // Determine which panel changed by comparing with current state
      setPanels((prevPanels) => {
        for (let i = 0; i < 3; i++) {
          if (prevPanels[i] !== data.panels[i]) {
            setChangingPanel(i);
            // Reset the changing indicator after animation completes
            setTimeout(() => setChangingPanel(null), data.fadeDuration);
            break;
          }
        }
        return data.panels;
      });
    });

    // Request initial state from main window immediately so panels aren't black
    emit('request-triptych-update', {}).catch((e) => console.warn(e));

    return () => {
      unlisten.then((fn) => fn());
    };
  }, []);

  if (role === 'left') {
    return (
      <div className="w-full h-full relative overflow-hidden bg-black select-none">
        <div
          className="flex h-full box-border transition-all duration-300 absolute top-0"
          style={{
            width: `calc(200vw - ${overlap}px)`,
            left: 0,
            gap: `${panelGap}px`,
            padding: `${outerMargin}px`,
          }}
        >
          {panels.map((url, i) => (
            <Panel
              key={i}
              imageUrl={url}
              fadeDuration={fadeDuration}
              isChanging={changingPanel === i}
            />
          ))}
        </div>

        {/* Soft edge blend gradient on right seam */}
        {edgeBlend && overlap > 0 && (
          <div
            className="absolute top-0 bottom-0 right-0 pointer-events-none z-30"
            style={{
              width: `${overlap}px`,
              background: 'linear-gradient(to right, transparent, rgba(0,0,0,1))',
            }}
          />
        )}
      </div>
    );
  }

  if (role === 'right') {
    return (
      <div className="w-full h-full relative overflow-hidden bg-black select-none">
        <div
          className="flex h-full box-border transition-all duration-300 absolute top-0"
          style={{
            width: `calc(200vw - ${overlap}px)`,
            left: `calc(-100vw + ${overlap}px)`,
            gap: `${panelGap}px`,
            padding: `${outerMargin}px`,
          }}
        >
          {panels.map((url, i) => (
            <Panel
              key={i}
              imageUrl={url}
              fadeDuration={fadeDuration}
              isChanging={changingPanel === i}
            />
          ))}
        </div>

        {/* Soft edge blend gradient on left seam */}
        {edgeBlend && overlap > 0 && (
          <div
            className="absolute top-0 bottom-0 left-0 pointer-events-none z-30"
            style={{
              width: `${overlap}px`,
              background: 'linear-gradient(to right, rgba(0,0,0,1), transparent)',
            }}
          />
        )}
      </div>
    );
  }

  // Single projector mode (default)
  return (
    <div
      className="flex w-full h-full box-border transition-all duration-300 relative"
      style={{
        gap: `${panelGap}px`,
        padding: `${outerMargin}px`,
      }}
    >
      {panels.map((url, i) => (
        <Panel
          key={i}
          imageUrl={url}
          fadeDuration={fadeDuration}
          isChanging={changingPanel === i}
        />
      ))}
    </div>
  );
}
