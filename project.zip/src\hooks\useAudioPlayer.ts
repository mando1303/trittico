import { useEffect, useRef } from 'react';
import { useStore } from '../stores/useStore';

export function useAudioPlayer() {
  const isPlaying = useStore((s) => s.isPlaying);
  const audioTracks = useStore((s) => s.audioTracks);
  const audioSettings = useStore((s) => s.audioSettings);
  const currentAudioIndex = useStore((s) => s.currentAudioIndex);
  const nextAudioTrack = useStore((s) => s.nextAudioTrack);
  const previewAudioId = useStore((s) => s.previewAudioId);
  const setPreviewAudio = useStore((s) => s.setPreviewAudio);

  const mainAudioRef = useRef<HTMLAudioElement | null>(null);
  const mainAudioCtxRef = useRef<AudioContext | null>(null);
  const mainGainNodeRef = useRef<GainNode | null>(null);
  const currentPlayingTrackIdRef = useRef<string | null>(null);

  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  const previewAudioCtxRef = useRef<AudioContext | null>(null);
  const previewGainNodeRef = useRef<GainNode | null>(null);

  // Unlock AudioContext on first user interaction (browser autoplay policy)
  useEffect(() => {
    const unlock = () => {
      if (mainAudioCtxRef.current && mainAudioCtxRef.current.state === 'suspended') {
        mainAudioCtxRef.current.resume().catch(() => {});
      }
      if (previewAudioCtxRef.current && previewAudioCtxRef.current.state === 'suspended') {
        previewAudioCtxRef.current.resume().catch(() => {});
      }
    };
    window.addEventListener('click', unlock, { passive: true });
    window.addEventListener('keydown', unlock, { passive: true });
    return () => {
      window.removeEventListener('click', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, []);

  // Initialize main audio element with Web Audio GainNode & Limiter for volume boost up to 250%
  useEffect(() => {
    const audio = new Audio();
    audio.preload = 'auto';
    audio.crossOrigin = 'anonymous';
    mainAudioRef.current = audio;

    try {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtxClass) {
        const ctx = new AudioCtxClass();
        mainAudioCtxRef.current = ctx;

        const source = ctx.createMediaElementSource(audio);
        const gainNode = ctx.createGain();
        const compressor = ctx.createDynamicsCompressor();

        // Limiter compressor settings to prevent digital clipping when volume > 100%
        compressor.threshold.setValueAtTime(-1.5, ctx.currentTime);
        compressor.knee.setValueAtTime(6, ctx.currentTime);
        compressor.ratio.setValueAtTime(16, ctx.currentTime);
        compressor.attack.setValueAtTime(0.002, ctx.currentTime);
        compressor.release.setValueAtTime(0.15, ctx.currentTime);

        source.connect(gainNode);
        gainNode.connect(compressor);
        compressor.connect(ctx.destination);

        mainGainNodeRef.current = gainNode;
      }
    } catch (e) {
      console.warn('Web Audio amplification setup error for main slideshow audio:', e);
    }

    const handleEnded = () => {
      nextAudioTrack();
    };

    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('ended', handleEnded);
      audio.pause();
      audio.src = '';
      if (mainAudioCtxRef.current && mainAudioCtxRef.current.state !== 'closed') {
        mainAudioCtxRef.current.close().catch(() => {});
      }
      mainAudioRef.current = null;
      mainAudioCtxRef.current = null;
      mainGainNodeRef.current = null;
    };
  }, [nextAudioTrack]);

  // Apply volume & gain amplification whenever audioSettings.volume changes
  useEffect(() => {
    const audio = mainAudioRef.current;
    if (!audio) return;

    const targetVolume = Math.max(0, audioSettings.volume);

    if (mainGainNodeRef.current && mainAudioCtxRef.current) {
      // Use Web Audio GainNode for clean amplification up to 2.5x (250%)
      audio.volume = 1.0;
      mainGainNodeRef.current.gain.setValueAtTime(
        targetVolume,
        mainAudioCtxRef.current.currentTime
      );
    } else {
      // Fallback: standard HTML5 audio (clamped to 0..1)
      audio.volume = Math.min(1, targetVolume);
    }
  }, [audioSettings.volume]);

  // Handle main slideshow audio playback state & track changes
  useEffect(() => {
    const audio = mainAudioRef.current;
    if (!audio) return;

    if (!audioSettings.enabled || audioTracks.length === 0) {
      audio.pause();
      currentPlayingTrackIdRef.current = null;
      return;
    }

    const currentTrack = audioTracks[currentAudioIndex];
    if (!currentTrack) {
      audio.pause();
      currentPlayingTrackIdRef.current = null;
      return;
    }

    // Update track source if changed
    if (currentPlayingTrackIdRef.current !== currentTrack.id) {
      currentPlayingTrackIdRef.current = currentTrack.id;
      audio.src = currentTrack.assetUrl;
    }

    if (isPlaying) {
      // Resume AudioContext if suspended
      if (mainAudioCtxRef.current && mainAudioCtxRef.current.state === 'suspended') {
        mainAudioCtxRef.current.resume().catch(() => {});
      }

      // Stop individual preview audio if active
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
        setPreviewAudio(null);
      }

      audio.play().catch((err) => {
        console.warn('Audio playback failed or interrupted:', err);
      });
    } else {
      audio.pause();
    }
  }, [isPlaying, audioTracks, currentAudioIndex, audioSettings.enabled, setPreviewAudio]);

  // Initialize preview audio element with Web Audio booster
  useEffect(() => {
    const preview = new Audio();
    preview.preload = 'auto';
    preview.crossOrigin = 'anonymous';
    previewAudioRef.current = preview;

    try {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtxClass) {
        const ctx = new AudioCtxClass();
        previewAudioCtxRef.current = ctx;

        const source = ctx.createMediaElementSource(preview);
        const gainNode = ctx.createGain();
        const compressor = ctx.createDynamicsCompressor();

        compressor.threshold.setValueAtTime(-1.5, ctx.currentTime);
        compressor.knee.setValueAtTime(6, ctx.currentTime);
        compressor.ratio.setValueAtTime(16, ctx.currentTime);
        compressor.attack.setValueAtTime(0.002, ctx.currentTime);
        compressor.release.setValueAtTime(0.15, ctx.currentTime);

        source.connect(gainNode);
        gainNode.connect(compressor);
        compressor.connect(ctx.destination);

        previewGainNodeRef.current = gainNode;
      }
    } catch (e) {
      console.warn('Web Audio amplification setup error for preview audio:', e);
    }

    return () => {
      preview.pause();
      preview.src = '';
      if (previewAudioCtxRef.current && previewAudioCtxRef.current.state !== 'closed') {
        previewAudioCtxRef.current.close().catch(() => {});
      }
      previewAudioRef.current = null;
      previewAudioCtxRef.current = null;
      previewGainNodeRef.current = null;
    };
  }, []);

  // Update preview volume
  useEffect(() => {
    const preview = previewAudioRef.current;
    if (!preview) return;

    const targetVolume = Math.max(0, audioSettings.volume);
    if (previewGainNodeRef.current && previewAudioCtxRef.current) {
      preview.volume = 1.0;
      previewGainNodeRef.current.gain.setValueAtTime(
        targetVolume,
        previewAudioCtxRef.current.currentTime
      );
    } else {
      preview.volume = Math.min(1, targetVolume);
    }
  }, [audioSettings.volume]);

  // Handle individual preview playback in gallery
  useEffect(() => {
    const preview = previewAudioRef.current;
    if (!preview) return;

    if (!previewAudioId) {
      preview.pause();
      preview.src = '';
      return;
    }

    const track = audioTracks.find((t) => t.id === previewAudioId);
    if (!track) {
      setPreviewAudio(null);
      return;
    }

    preview.src = track.assetUrl;

    if (previewAudioCtxRef.current && previewAudioCtxRef.current.state === 'suspended') {
      previewAudioCtxRef.current.resume().catch(() => {});
    }

    const handlePreviewEnded = () => {
      setPreviewAudio(null);
    };

    preview.addEventListener('ended', handlePreviewEnded, { once: true });
    preview.play().catch((err) => console.warn('Preview play error:', err));

    return () => {
      preview.removeEventListener('ended', handlePreviewEnded);
    };
  }, [previewAudioId, audioTracks, setPreviewAudio]);

  return {
    currentTrack: audioTracks[currentAudioIndex] || null,
    audioTracksCount: audioTracks.length,
  };
}
