import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useStore } from '../../stores/useStore';
import { getCurrentWindow } from '@tauri-apps/api/window';
import FloatingControllerWindow from './FloatingControllerWindow';

export default function FullPreviewModal() {
  const isFullPreviewOpen = useStore((s) => s.isFullPreviewOpen);
  const setFullPreviewOpen = useStore((s) => s.setFullPreviewOpen);
  const triptych = useStore((s) => s.triptych);
  const images = useStore((s) => s.images);
  const settings = useStore((s) => s.settings);
  const togglePlay = useStore((s) => s.togglePlay);
  const advanceSlideshow = useStore((s) => s.advanceSlideshow);

  const [isControllerOpen, setControllerOpen] = useState(false);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Toggle controller window with 'C'
      if (e.key === 'c' || e.key === 'C') {
        e.preventDefault();
        setControllerOpen((prev) => !prev);
      } else if (e.key === 'Escape') {
        e.preventDefault();
        if (isControllerOpen) {
          setControllerOpen(false);
        } else {
          setFullPreviewOpen(false);
        }
      } else if (e.key === ' ' || e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'ArrowRight' || e.key === 'n' || e.key === 'N') {
        e.preventDefault();
        advanceSlideshow();
      }
    };

    if (isFullPreviewOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFullPreviewOpen, isControllerOpen, togglePlay, setFullPreviewOpen, advanceSlideshow]);

  // Set native window to true fullscreen when preview opens, restore on close
  useEffect(() => {
    if (isFullPreviewOpen) {
      getCurrentWindow().setFullscreen(true).catch((e) => console.warn(e));
    } else {
      getCurrentWindow().setFullscreen(false).catch((e) => console.warn(e));
    }
  }, [isFullPreviewOpen]);

  if (!isFullPreviewOpen) return null;

  const displayPanels = triptych.panels[0]
    ? triptych.panels
    : [
        images[0]?.assetUrl || null,
        images[1]?.assetUrl || null,
        images[2]?.assetUrl || null,
      ];

  const durationSec = settings.fadeDuration / 1000;

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col select-none overflow-hidden">
      {/* Discreet top-right trigger - does not block images */}
      <div className="absolute top-3 right-3 z-40 flex items-center gap-2 opacity-30 hover:opacity-100 transition-opacity duration-200">
        <button
          onClick={() => setControllerOpen((prev) => !prev)}
          className="px-2.5 py-1.5 bg-gray-900/80 hover:bg-gray-800 border border-gray-700/80 rounded-lg text-xs font-semibold text-gray-200 hover:text-white cursor-pointer transition-colors shadow-lg backdrop-blur flex items-center gap-1.5"
          title="Mostra / Nascondi finestra controlli (tasto C)"
        >
          <span>🎬</span>
          <span>Controlli</span>
          <kbd className="text-[10px] bg-gray-800 px-1 py-0.5 rounded text-gray-400 border border-gray-700">C</kbd>
        </button>

        <button
          onClick={() => setFullPreviewOpen(false)}
          className="p-1.5 bg-gray-900/80 hover:bg-gray-700 border border-gray-700/80 rounded-lg text-xs font-semibold text-gray-200 hover:text-white cursor-pointer transition-colors shadow-lg backdrop-blur"
          title="Chiudi anteprima (Esc)"
        >
          ✕
        </button>
      </div>

      {/* Main 3-Panel Triptych view: 100% clean presentation */}
      <div
        className="flex-1 w-full h-full flex items-center justify-center box-border transition-all duration-200"
        style={{
          gap: `${settings.panelGap ?? 0}px`,
          padding: `${settings.outerMargin ?? 0}px`,
        }}
      >
        {displayPanels.map((url, index) => (
          <div
            key={index}
            className="flex-1 h-full bg-black relative flex items-center justify-center overflow-hidden"
          >
            <AnimatePresence mode="wait">
              {url ? (
                <motion.img
                  key={url}
                  src={url}
                  alt={`Pannello ${index + 1}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: durationSec, ease: 'easeInOut' }}
                  className="w-full h-full object-contain absolute inset-0 select-none pointer-events-none"
                  draggable={false}
                />
              ) : (
                <div className="text-gray-700 text-sm font-medium">
                  {images.length === 0 ? 'Nessuna immagine' : `Pannello ${index + 1}`}
                </div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>

      {/* Separate Controller Window that appears on command */}
      <AnimatePresence>
        {isControllerOpen && (
          <FloatingControllerWindow
            onClose={() => setControllerOpen(false)}
            onExitPreview={() => setFullPreviewOpen(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
