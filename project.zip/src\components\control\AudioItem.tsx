import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { AudioTrack } from '../../types';
import { useStore } from '../../stores/useStore';

interface Props {
  track: AudioTrack;
  index: number;
}

export default function AudioItem({ track, index }: Props) {
  const removeAudioTrack = useStore((s) => s.removeAudioTrack);
  const currentAudioIndex = useStore((s) => s.currentAudioIndex);
  const setCurrentAudioIndex = useStore((s) => s.setCurrentAudioIndex);
  const isPlaying = useStore((s) => s.isPlaying);
  const previewAudioId = useStore((s) => s.previewAudioId);
  const setPreviewAudio = useStore((s) => s.setPreviewAudio);

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: track.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.4 : 1,
  };

  const isCurrentInSlideshow = currentAudioIndex === index;
  const isCurrentlyPreviewing = previewAudioId === track.id;

  const handleTogglePreview = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isCurrentlyPreviewing) {
      setPreviewAudio(null);
    } else {
      setPreviewAudio(track.id);
    }
  };

  const handleSelectTrack = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentAudioIndex(index);
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    removeAudioTrack(track.id);
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={`group relative flex items-center justify-between p-3 rounded-lg border transition-all cursor-grab active:cursor-grabbing select-none ${
        isCurrentInSlideshow && isPlaying
          ? 'bg-blue-950/60 border-blue-500 shadow-md shadow-blue-500/20'
          : isCurrentInSlideshow
          ? 'bg-gray-800 border-blue-600/70'
          : 'bg-gray-850 bg-gray-800/60 hover:bg-gray-800 border-gray-700/60 hover:border-gray-600'
      }`}
    >
      {/* Left: Drag Handle, Index and Audio Icon */}
      <div className="flex items-center gap-3 min-w-0 flex-1">
        <span className="text-gray-500 text-xs font-mono w-5 shrink-0 text-center">
          {index + 1}
        </span>

        {/* Thumbnail / Wave icon box */}
        <div
          className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 border ${
            isCurrentInSlideshow && isPlaying
              ? 'bg-blue-600/30 border-blue-400 text-blue-300 animate-pulse'
              : isCurrentlyPreviewing
              ? 'bg-emerald-600/30 border-emerald-400 text-emerald-300 animate-pulse'
              : 'bg-gray-700/60 border-gray-600 text-gray-300'
          }`}
        >
          <span className="text-lg">
            {isCurrentInSlideshow && isPlaying ? '🔊' : isCurrentlyPreviewing ? '▶' : '🎵'}
          </span>
        </div>

        {/* Track info */}
        <div className="flex flex-col min-w-0 flex-1 pr-2">
          <span
            className="text-xs font-medium text-gray-200 truncate group-hover:text-white"
            title={track.name}
          >
            {track.name}
          </span>
          <div className="flex items-center gap-2 mt-0.5">
            {isCurrentInSlideshow && (
              <span className="text-[10px] font-semibold text-blue-400 bg-blue-950/80 px-1.5 py-0.2 rounded border border-blue-800">
                {isPlaying ? '● In riproduzione' : 'Traccia pronta'}
              </span>
            )}
            {isCurrentlyPreviewing && (
              <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/80 px-1.5 py-0.2 rounded border border-emerald-800">
                ● Ascolto anteprima
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Right action buttons (stop pointer propagation so dragging isn't triggered) */}
      <div
        className="flex items-center gap-1.5 shrink-0"
        onPointerDown={(e) => e.stopPropagation()}
      >
        {/* Preview play/pause button */}
        <button
          onClick={handleTogglePreview}
          className={`px-2 py-1 rounded text-xs font-semibold cursor-pointer transition-colors flex items-center gap-1 border ${
            isCurrentlyPreviewing
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-500'
              : 'bg-gray-700/80 hover:bg-gray-650 text-gray-300 hover:text-white border-gray-600'
          }`}
          title={isCurrentlyPreviewing ? 'Interrompi anteprima' : 'Ascolta anteprima di questa traccia'}
        >
          <span>{isCurrentlyPreviewing ? '⏸' : '▶'}</span>
          <span className="hidden sm:inline text-[11px]">
            {isCurrentlyPreviewing ? 'Stop' : 'Ascolta'}
          </span>
        </button>

        {/* Set as starting track button */}
        {!isCurrentInSlideshow && (
          <button
            onClick={handleSelectTrack}
            className="px-2 py-1 rounded text-xs bg-gray-700/50 hover:bg-gray-700 text-gray-400 hover:text-blue-300 border border-gray-700 cursor-pointer transition-colors"
            title="Imposta come prima traccia dello slideshow"
          >
            Scegli
          </button>
        )}

        {/* Delete button */}
        <button
          onClick={handleDelete}
          className="p-1 text-gray-400 hover:text-red-400 hover:bg-red-500/10 rounded transition-colors cursor-pointer"
          title="Rimuovi traccia"
        >
          ✕
        </button>
      </div>
    </div>
  );
}
